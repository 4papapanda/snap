package com.Funmovieslix

import com.lagradost.api.Log
import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.base64DecodeArray
import com.lagradost.cloudstream3.extractors.VidhideExtractor
import com.lagradost.cloudstream3.utils.ExtractorApi
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import com.lagradost.cloudstream3.utils.newExtractorLink
import org.json.JSONObject
import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.cloudstream3.utils.AppUtils.tryParseJson
import com.lagradost.cloudstream3.utils.M3u8Helper
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URI
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec


class Ryderjet : VidhideExtractor() {
    override var mainUrl = "https://ryderjet.com"
}

class Dhtpre : VidhideExtractor() {
    override var mainUrl = "https://dhtpre.com"
}


class Vidhideplus : VidhideExtractor() {
    override var mainUrl = "https://vidhideplus.com"
}


//Thanks to https://github.com/VVytai/jdownloader_mirror/blob/main/svn_trunk/src/jd/plugins/hoster/LixstreamCom.java
class VideyV2 : ExtractorApi() {
    override var name = "Videy"
    override var mainUrl = "https://videy.tv"
    override val requiresReferer = false

    private val apiBase = "https://api.lixstreamingcaio.com/v2"

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ) {
        val sid = url.substringAfterLast("/")
        Log.d("Phisher", "sid=$sid")

        val infoRes = app.post(
            "$apiBase/s/home/resources/$sid",
            data = mapOf(),
            headers = mapOf("Content-Type" to "application/json")
        ).text

        val info = runCatching { JSONObject(infoRes) }.getOrNull() ?: return
        val suid = info.optString("suid") ?: return
        val files = info.optJSONArray("files") ?: return
        if (files.length() == 0) return
        val file = files.optJSONObject(0) ?: return
        val fid = file.optString("id") ?: return
        val assetRes = app.get("$apiBase/s/assets/f?id=$fid&uid=$suid").text
        val asset = runCatching { JSONObject(assetRes) }.getOrNull() ?: return
        val encryptedUrl = asset.optString("url")
        if (encryptedUrl.isNullOrEmpty()) {
            Log.e("Error:", "No encrypted url found")
            return
        }
        val key = "GNgN1lHXIFCQd8hSEZIeqozKInQTFNXj".toByteArray(Charsets.UTF_8)
        val iv = "2Xk4dLo38c9Z2Q2a".toByteArray(Charsets.UTF_8)
        val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(key, "AES"),
            javax.crypto.spec.IvParameterSpec(iv)
        )
        val decrypted = runCatching {
            val decoded = base64DecodeArray(encryptedUrl)
            String(cipher.doFinal(decoded), Charsets.UTF_8)
        }.getOrNull() ?: return
        callback.invoke(
            newExtractorLink(
                this.name,
                this.name,
                decrypted,
                if (decrypted.contains(".mp4")) ExtractorLinkType.VIDEO else ExtractorLinkType.M3U8
            )
            {
                this.referer = url
                this.quality = Qualities.P1080.value
            }
        )
    }
}

class Bysezoxexe : ByseSX() {
    override var name = "Bysezoxexe"
    override var mainUrl = "https://bysezoxexe.com"
}

open class ByseSX : ExtractorApi() {
    override var name = "Byse"
    override var mainUrl = "https://byse.sx"
    override val requiresReferer = true

    private fun b64UrlDecode(s: String): ByteArray {
        val fixed = s.replace('-', '+').replace('_', '/')
        val pad = (4 - fixed.length % 4) % 4
        return base64DecodeArray(fixed + "=".repeat(pad))
    }

    private fun getBaseUrl(url: String): String {
        return URI(url).let { "${it.scheme}://${it.host}" }
    }

    private fun getCodeFromUrl(url: String): String {
        val parts = URI(url).path.trim('/').split('/').filter { it.isNotBlank() }
        return when {
            parts.firstOrNull().equals("e", true) && parts.size >= 2 -> parts[1]
            parts.firstOrNull().equals("d", true) && parts.size >= 2 -> parts[1]
            parts.firstOrNull().equals("download", true) && parts.size >= 2 -> parts[1]
            parts.firstOrNull().equals("dwn", true) && parts.size >= 2 -> parts[1]
            parts.size >= 2 && parts[0].length in 3..5 -> parts[1]
            parts.isNotEmpty() -> parts.last()
            else -> ""
        }
    }

    private suspend fun getPlayback(pageUrl: String, referer: String?): PlaybackRoot? {
        val embedBase = getBaseUrl(pageUrl)
        val code = getCodeFromUrl(pageUrl)
        val playbackUrl = "$embedBase/api/videos/$code/embed/playback"
        val headers = getEmbedHeaders(pageUrl, referer)
        val captchaToken = runCatching {
            app.get("$embedBase/api/videos/$code/embed/settings", headers = headers)
                .parsedSafe<ByseSettings>()
                ?.takeIf { it.captchaRequired }
                ?.let { getCaptchaToken(embedBase, code, pageUrl, referer) }
        }.getOrNull()
        val body = """{"fingerprint":{"token":"","viewer_id":"$code","device_id":"$code","confidence":0.1}}"""
            .toRequestBody("application/json".toMediaTypeOrNull())
        return app.post(
            playbackUrl,
            headers = if (captchaToken.isNullOrBlank()) headers else headers + ("X-Captcha-Token" to captchaToken),
            requestBody = body,
        ).parsedSafe<PlaybackRoot>()
    }

    private suspend fun getCaptchaToken(embedBase: String, code: String, pageUrl: String, referer: String?): String? {
        val headers = getEmbedHeaders(pageUrl, referer)
        val body = """{"fingerprint":{"token":"","viewer_id":"$code","device_id":"$code","confidence":0.1}}"""
            .toRequestBody("application/json".toMediaTypeOrNull())
        val challenge = app.post(
            "$embedBase/api/videos/$code/embed/captcha",
            headers = headers,
            requestBody = body,
        ).parsedSafe<BysePowChallenge>() ?: return null
        val solution = solvePow(challenge.nonce, challenge.difficulty) ?: return null
        val verifyBody = """{"pow_token":"${challenge.token}","solution":"$solution"}"""
            .toRequestBody("application/json".toMediaTypeOrNull())
        return app.post(
            "$embedBase/api/videos/$code/embed/captcha/verify",
            headers = headers,
            requestBody = verifyBody,
        ).parsedSafe<BysePowVerify>()?.takeIf { it.status == "ok" }?.token
    }

    private fun getEmbedHeaders(pageUrl: String, referer: String?): Map<String, String> {
        val parentHost = referer?.let { runCatching { URI(it).host }.getOrNull() } ?: getBaseUrl(pageUrl)
        val parentReferer = referer ?: pageUrl
        return mapOf(
            "accept" to "*/*",
            "accept-language" to "en-US,en;q=0.5",
            "content-type" to "application/json",
            "referer" to pageUrl,
            "X-Embed-Origin" to parentHost,
            "X-Embed-Referer" to parentReferer,
            "X-Embed-Parent" to pageUrl,
        )
    }

    private fun buildAesKey(playback: Playback): ByteArray {
        val parts = getVersionedKeyParts(playback)
        return b64UrlDecode(parts[0]) + b64UrlDecode(parts[1])
    }

    private fun getVersionedKeyParts(playback: Playback): List<String> {
        val parts = playback.keyParts
        val version = playback.version?.toIntOrNull()
        val selected = version
            ?.let { listOf(it, 31 - it) }
            ?.mapNotNull { index -> parts.getOrNull(index - 1) }
            ?.filter { it.isNotBlank() }
            .orEmpty()

        return if (selected.size == 2) selected else parts.take(2)
    }

    private fun decryptPlayback(playback: Playback): String? {
        val keyBytes = buildAesKey(playback)
        val ivBytes = b64UrlDecode(playback.iv)
        val cipherBytes = b64UrlDecode(playback.payload)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val spec = GCMParameterSpec(128, ivBytes)
        val secretKey = SecretKeySpec(keyBytes, "AES")
        cipher.init(Cipher.DECRYPT_MODE, secretKey, spec)

        val plainBytes = cipher.doFinal(cipherBytes)
        var jsonStr = String(plainBytes, StandardCharsets.UTF_8)

        if (jsonStr.startsWith("\uFEFF")) jsonStr = jsonStr.substring(1)

        val root = try {
            tryParseJson<PlaybackDecrypt>((jsonStr))
        } catch (_: Exception) {
            return null
        }

        return root?.sources?.firstOrNull()?.url
    }


    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ) {
        val refererUrl = getBaseUrl(url)
        val playbackRoot = getPlayback(url, referer) ?: return
        val streamUrl  = decryptPlayback(playbackRoot.playback) ?: return


        val headers = mapOf("Referer" to refererUrl)
        val links = M3u8Helper.generateM3u8(
            name,
            streamUrl,
            mainUrl,
            headers = headers
        )

        if (links.isNotEmpty()) {
            links.forEach(callback)
        } else {
            callback(
                newExtractorLink(
                    source = name,
                    name = name,
                    url = streamUrl,
                    type = ExtractorLinkType.M3U8,
                ) {
                    this.referer = refererUrl
                    this.quality = Qualities.Unknown.value
                }
            )
        }
    }

    private fun solvePow(nonce: String, difficulty: Int, timeoutMs: Long = 20_000): String? {
        if (difficulty <= 0) return "0"
        val started = System.currentTimeMillis()
        val prefix = "$nonce:"
        var counter = 0
        while (System.currentTimeMillis() - started <= timeoutMs) {
            repeat(1024) {
                if (leadingZeroBits(powHash("$prefix$counter")) >= difficulty) return counter.toString()
                counter++
            }
        }
        Log.w("Byse", "PoW solve timed out for difficulty $difficulty")
        return null
    }

    private fun powHash(value: String): IntArray {
        val state = intArrayOf(1779033703, -1150833019, 1013904242, -1521486534)
        value.forEach { char ->
            state[0] += char.code and 0xff
            state[0] = Integer.rotateLeft(state[0], 7)
            powMix(state)
        }
        repeat(8) { powMix(state) }
        val scratch = IntArray(512)
        repeat(scratch.size) { index ->
            powMix(state)
            scratch[index] = state[0] xor state[2]
        }
        repeat(2) {
            for (index in scratch.indices) {
                val target = scratch[index] and 511
                var current = scratch[index] + scratch[target]
                current = Integer.rotateLeft(current, 13)
                current = current xor (scratch[(index + 1) and 511] * -1640531535)
                scratch[index] = current
                state[0] = state[0] xor current
                powMix(state)
            }
        }
        return IntArray(8) { index ->
            powMix(state)
            var current = state[0]
            val start = index * 64
            for (offset in 0 until 64) {
                val item = scratch[start + offset]
                current += item
                current = Integer.rotateLeft(current, 5)
                current = current xor (item * -2048144777)
            }
            current xor state[2]
        }
    }

    private fun powMix(state: IntArray) {
        state[0] += state[1]
        state[3] = Integer.rotateLeft(state[3] xor state[0], 16)
        state[2] += state[3]
        state[1] = Integer.rotateLeft(state[1] xor state[2], 12)
        state[0] += state[1]
        state[3] = Integer.rotateLeft(state[3] xor state[0], 8)
        state[2] += state[3]
        state[1] = Integer.rotateLeft(state[1] xor state[2], 7)
    }

    private fun leadingZeroBits(values: IntArray): Int {
        var bits = 0
        for (value in values) {
            if (value == 0) {
                bits += 32
            } else {
                return bits + Integer.numberOfLeadingZeros(value)
            }
        }
        return bits
    }
}

data class ByseSettings(
    @param:JsonProperty("captcha_required")
    val captchaRequired: Boolean = false,
)

data class BysePowChallenge(
    @param:JsonProperty("pow_nonce")
    val nonce: String,
    @param:JsonProperty("pow_difficulty")
    val difficulty: Int,
    @param:JsonProperty("pow_token")
    val token: String,
)

data class BysePowVerify(
    val status: String? = null,
    val token: String? = null,
)

data class DetailsRoot(
    val id: Long,
    val code: String,
    val title: String,
    @param:JsonProperty("poster_url")
    val posterUrl: String,
    val description: String,
    @param:JsonProperty("created_at")
    val createdAt: String,
    @param:JsonProperty("owner_private")
    val ownerPrivate: Boolean,
    @param:JsonProperty("embed_frame_url")
    val embedFrameUrl: String,
)

data class PlaybackRoot(
    val playback: Playback,
)

data class Playback(
    val algorithm: String? = null,
    val iv: String,
    val payload: String,
    val version: String? = null,
    @param:JsonProperty("key_parts")
    val keyParts: List<String>,
    @param:JsonProperty("expires_at")
    val expiresAt: String? = null,
)

data class DecryptKeys(
    @param:JsonProperty("edge_1")
    val edge1: String,
    @param:JsonProperty("edge_2")
    val edge2: String,
    @param:JsonProperty("legacy_fallback")
    val legacyFallback: String,
)

data class PlaybackDecrypt(
    val sources: List<PlaybackDecryptSource>? = null,
)

data class PlaybackDecryptSource(
    val quality: String,
    val label: String,
    @param:JsonProperty("mime_type")
    val mimeType: String,
    val url: String,
    @param:JsonProperty("bitrate_kbps")
    val bitrateKbps: Long,
    val height: Any?,
)

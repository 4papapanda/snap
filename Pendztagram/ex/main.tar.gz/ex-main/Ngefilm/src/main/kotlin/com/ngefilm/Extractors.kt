package com.ngefilm

import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.utils.ExtractorApi
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.*
import com.lagradost.cloudstream3.USER_AGENT
import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.utils.M3u8Helper.Companion.generateM3u8
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import com.lagradost.cloudstream3.utils.AppUtils.tryParseJson
import com.lagradost.cloudstream3.base64Decode
import com.lagradost.cloudstream3.extractors.StreamWishExtractor
import com.lagradost.cloudstream3.extractors.Gdriveplayer
import com.lagradost.cloudstream3.extractors.VidStack
import com.lagradost.cloudstream3.extractors.Hxfile
import com.lagradost.cloudstream3.extractors.DoodLaExtractor
import com.fasterxml.jackson.annotation.JsonProperty
import java.net.URI
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject

class Movearnpre : Dingtezuni() {
    override var name = "Earnvids"
    override var mainUrl = "https://movearnpre.com"
}

class Vidhidepre : Dingtezuni() {
    override var name = "Vidhidepre"
    override var mainUrl = "https://vidhidepre.com"
}

class Dhtpre : Dingtezuni() {
    override var name = "Earnvids"
    override var mainUrl = "https://dhtpre.com"
}

class Mivalyo : Dingtezuni() {
    override var name = "Earnvids"
    override var mainUrl = "https://mivalyo.com"
}

class Bingezove : Dingtezuni() {
    override var name = "Earnvids"
    override var mainUrl = "https://bingezove.com"
}

open class Dingtezuni : ExtractorApi() {
    override val name = "Earnvids"
    override val mainUrl = "https://dingtezuni.com"
    override val requiresReferer = true

 override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ) {
        val headers = mapOf(
            "Sec-Fetch-Dest" to "empty",
            "Sec-Fetch-Mode" to "cors",
            "Sec-Fetch-Site" to "cross-site",
            "Origin" to mainUrl,
	        "User-Agent" to USER_AGENT,
        )
        
        val response = app.get(getEmbedUrl(url), referer = referer)
        val script = if (!getPacked(response.text).isNullOrEmpty()) {
            var result = getAndUnpack(response.text)
            if(result.contains("var links")){
                result = result.substringAfter("var links")
            }
            result
        } else {
            response.document.selectFirst("script:containsData(sources:)")?.data()
        } ?: return

        // m3u8 urls could be prefixed by 'file:', 'hls2:' or 'hls4:', so we just match ':'
        Regex(":\\s*\"(.*?m3u8.*?)\"").findAll(script).forEach { m3u8Match ->
            generateM3u8(
                name,
                fixUrl(m3u8Match.groupValues[1]),
                referer = "$mainUrl/",
                headers = headers
            ).forEach(callback)
        }
    }

    private fun getEmbedUrl(url: String): String {
		return when {
			url.contains("/d/") -> url.replace("/d/", "/v/")
			url.contains("/download/") -> url.replace("/download/", "/v/")
			url.contains("/file/") -> url.replace("/file/", "/v/")
			else -> url.replace("/f/", "/v/")
		}
	}

}

class Hglink : StreamWishExtractor() {
    override val name = "Hglink"
    override val mainUrl = "https://hglink.to"
}

class Hgcloud : StreamWishExtractor() {
    override val name = "Hgcloud"
    override val mainUrl = "https://hgcloud.to"
}

class Gdriveplayerto : Gdriveplayer() {
    override val mainUrl: String = "https://gdriveplayer.to"
}

class Playerngefilm21 : VidStack() {
    override var name = "Playerngefilm21"
    override var mainUrl = "https://playerngefilm21.rpmlive.online"
    override var requiresReferer = true
}

class P2pplay : VidStack() {
    override var name = "P2pplay"
    override var mainUrl = "https://nf21.p2pplay.pro"
    override var requiresReferer = true
}

class Xshotcok : Hxfile() {
    override val name = "Xshotcok"
    override val mainUrl = "https://xshotcok.com"
}

class Dsvplay : DoodLaExtractor() {
    override var mainUrl = "https://dsvplay.com"
}

class Vidara : ExtractorApi() {
    override val name = "Vidara"
    override val mainUrl = "https://vidara.to"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit,
    ) {
        val fileCode = URI(url).path.trim('/').substringAfterLast('/').takeIf { it.isNotBlank() } ?: return
        val pageUrl = "$mainUrl/e/$fileCode"
        val requestBody = """{"filecode":"$fileCode","device":"web"}"""
            .toRequestBody("application/json".toMediaTypeOrNull())
        val headers = mapOf(
            "User-Agent" to USER_AGENT,
            "Origin" to mainUrl,
            "Referer" to pageUrl,
        )

        val json = JSONObject(
            app.post(
                "$mainUrl/api/stream",
                headers = headers + ("Content-Type" to "application/json"),
                requestBody = requestBody,
            ).text,
        )

        json.optJSONArray("subtitles")?.let { subtitles ->
            for (i in 0 until subtitles.length()) {
                val sub = subtitles.optJSONObject(i) ?: continue
                val file = sub.optString("file_path").takeIf { it.isNotBlank() } ?: continue
                subtitleCallback.invoke(
                    SubtitleFile(
                        sub.optString("language").ifBlank { "Subtitle" },
                        file,
                    ),
                )
            }
        }

        val streamUrl = json.optString("streaming_url").takeIf { it.isNotBlank() } ?: return
        val titleQuality = qualityFromText(json.optString("title"))
        val links = generateM3u8(
            name,
            streamUrl,
            referer = pageUrl,
            headers = headers,
        )

        if (links.isNotEmpty()) {
            links.forEach(callback)
        } else {
            callback.invoke(
                newExtractorLink(name, sourceName(titleQuality), streamUrl, ExtractorLinkType.M3U8) {
                    this.referer = pageUrl
                    if (titleQuality > 0) this.quality = titleQuality
                    this.headers = headers
                },
            )
        }
    }

    private fun qualityFromText(text: String): Int {
        return Regex("""(?<!\d)(2160|1440|1080|720|480|360)(?:p)?(?!\d)""", RegexOption.IGNORE_CASE)
            .find(text)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
            ?: 0
    }

    private fun sourceName(quality: Int): String {
        return if (quality > 0) "$name ${quality}p" else name
    }
}

open class Abyssplayer : ExtractorApi() {
    override val name = "AbyssPlayer"
    override val mainUrl = "https://abyssplayer.com"
    override val requiresReferer = true

    private val playHydraxUrl = "https://playhydrax.com"
    private val headers = mapOf(
        "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36",
        "Origin" to playHydraxUrl,
        "Referer" to "$playHydraxUrl/",
    )

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit,
    ) {
        val videoId = getVideoId(url) ?: return
        val pageUrls = listOf(
            url,
            "$mainUrl/$videoId",
            "https://abyssplayer.com/$videoId",
        ).distinct()

        pageUrls.firstNotNullOfOrNull { pageUrl ->
            runCatching {
                val page = app.get(pageUrl, headers = headers).document
                val scriptData = page.select("script").joinToString("\n") { it.data() }
                Regex("""const\s+datas\s*=\s*"([^"]*)"""")
                    .find(scriptData)
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.let { encrypted -> emitDecodedSources(encrypted, callback) }
            }.getOrNull()
        }?.let { return }

        val playerData = listOf(
            "https://abysscdn.com",
            "https://player-cdn.com",
        ).firstNotNullOfOrNull { playerBase ->
            try {
                val response = app.get(
                    "$playerBase/?v=$videoId",
                    referer = referer ?: "$mainUrl/",
                    headers = mapOf("User-Agent" to USER_AGENT),
                )
                Regex("""PLAYER\s*\(\s*atob\s*\(\s*["']([^"']+)["']""")
                    .find(response.text)
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.let { playerBase to it }
            } catch (_: Exception) {
                null
            }
        } ?: return

        val (playerBase, encoded) = playerData
        val payload = tryParseJson<AbyssPayload>(base64Decode(encoded)) ?: return
        val domain = payload.domain?.trim()?.trim('/') ?: return
        val fileId = payload.id?.trim() ?: return
        val sources = payload.sources.orEmpty()

        val emitted = mutableSetOf<String>()
        sources.forEach { source ->
            val prefix = prefixFromSource(source) ?: return@forEach
            val quality = qualityFromSource(source)
            emitSource(domain, prefix, fileId, playerBase, quality, emitted, callback)
        }

        if (emitted.isEmpty()) {
            listOf(
                "" to 360,
                "www" to 720,
                "whw" to 1080,
            ).forEach { (prefix, quality) ->
                emitSource(domain, prefix, fileId, playerBase, quality, emitted, callback)
            }
        }
    }

    private suspend fun emitDecodedSources(
        encrypted: String,
        callback: (ExtractorLink) -> Unit,
    ): Boolean {
        val requestBody = """{"text":"$encrypted"}"""
            .toRequestBody("application/json".toMediaTypeOrNull())
        val response = app.post(
            "https://enc-dec.app/api/dec-abyss",
            headers = headers,
            requestBody = requestBody,
        ).text

        val sources = JSONObject(response)
            .optJSONObject("result")
            ?.optJSONArray("sources")
            ?: return false

        val decodedSources = (0 until sources.length()).mapNotNull { i ->
            val source = sources.optJSONObject(i) ?: return@mapNotNull null
            if (!source.optBoolean("status", false)) return@mapNotNull null
            val sourceUrl = source.optString("url").takeIf { it.isNotBlank() } ?: return@mapNotNull null
            val parsedQuality = listOf(
                source.optString("label"),
                source.optString("quality"),
                source.optString("resolution"),
                source.optString("res"),
                source.optString("name"),
                sourceUrl,
            ).firstNotNullOfOrNull { qualityFromSource(it).takeIf { parsed -> parsed > 0 } } ?: 0

            DecodedAbyssSource(sourceUrl, parsedQuality)
        }

        var emitted = false
        decodedSources.forEachIndexed { index, source ->
            val estimatedQuality = estimatedQualityFromIndex(index, decodedSources.size)
            val quality = if (source.quality > 0) source.quality else estimatedQuality
            val isEstimated = source.quality == 0 && estimatedQuality > 0

            callback.invoke(
                newExtractorLink(
                    name,
                    sourceName(quality, isEstimated),
                    source.url,
                    if (source.url.contains(".m3u8", true)) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO,
                ) {
                    this.referer = "$playHydraxUrl/"
                    if (quality > 0) this.quality = quality
                    this.headers = headers
                },
            )
            emitted = true
        }

        return emitted
    }

    private suspend fun emitSource(
        domain: String,
        prefix: String,
        fileId: String,
        refererUrl: String,
        quality: Int,
        emitted: MutableSet<String>,
        callback: (ExtractorLink) -> Unit,
    ) {
        val mediaUrl = "https://$domain/$prefix$fileId"
        if (!emitted.add(mediaUrl)) return

        callback.invoke(
            newExtractorLink(name, sourceName(quality), mediaUrl, ExtractorLinkType.VIDEO) {
                this.referer = refererUrl
                if (quality > 0) this.quality = quality
                this.headers = mapOf(
                    "Referer" to refererUrl,
                    "User-Agent" to USER_AGENT,
                )
            },
        )
    }

    private fun getVideoId(url: String): String? {
        return URI(url).rawQuery
            ?.split("&")
            ?.firstOrNull { it.substringBefore("=") == "v" }
            ?.substringAfter("=")
            ?.takeIf { it.isNotBlank() }
            ?: URI(url).path.trim('/').takeIf { it.isNotBlank() }
    }

    private fun prefixFromSource(source: String): String? {
        return when (source.lowercase()) {
            "sd", "mhd", "360p", "480p" -> ""
            "hd", "720p" -> "www"
            "fullhd", "1080p" -> "whw"
            "qhd", "1440p" -> "uhd"
            "uhd", "4k", "2160p" -> "k4"
            else -> null
        }
    }

    private fun qualityFromSource(source: String): Int {
        val normalized = source.lowercase()
        Regex("""(?<!\d)(2160|1440|1080|720|480|360)(?:p)?(?!\d)""")
            .find(normalized)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
            ?.let { return it }

        return when {
            normalized.contains("fullhd") || normalized.contains("full_hd") -> 1080
            normalized.contains("qhd") -> 1440
            normalized.contains("uhd") || normalized.contains("4k") -> 2160
            normalized == "hd" -> 720
            normalized == "mhd" -> 480
            normalized == "sd" -> 360
            else -> 0
        }
    }

    private fun estimatedQualityFromIndex(index: Int, total: Int): Int {
        val ladder = when (total) {
            2 -> listOf(360, 720)
            3 -> listOf(360, 720, 1080)
            4 -> listOf(360, 480, 720, 1080)
            else -> listOf(360, 480, 720, 1080, 1440, 2160)
        }
        return if (total > 1) ladder.getOrElse(index) { 0 } else 0
    }

    private fun sourceName(quality: Int, estimated: Boolean = false): String {
        val marker = if (estimated) "~" else ""
        return if (quality > 0) "$name $marker${quality}p" else name
    }

    private data class DecodedAbyssSource(
        val url: String,
        val quality: Int,
    )
}

class Abysscdn : Abyssplayer() {
    override val name = "Abysscdn"
    override val mainUrl = "https://abysscdn.com"
}

data class AbyssPayload(
    val domain: String? = null,
    val id: String? = null,
    val sources: List<String>? = null,
)

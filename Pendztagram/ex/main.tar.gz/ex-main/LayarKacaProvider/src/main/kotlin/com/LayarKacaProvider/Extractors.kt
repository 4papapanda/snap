package com.layarKacaProvider

import com.lagradost.api.Log
import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.extractors.Filesim
import com.lagradost.cloudstream3.utils.AppUtils.toJson
import com.lagradost.cloudstream3.utils.ExtractorApi
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.INFER_TYPE
import com.lagradost.cloudstream3.utils.M3u8Helper
import com.lagradost.cloudstream3.utils.getQualityFromName
import com.lagradost.cloudstream3.utils.newExtractorLink
import com.lagradost.cloudstream3.utils.Qualities
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import org.json.JSONObject
import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.cloudstream3.Prerelease
import com.lagradost.cloudstream3.base64DecodeArray
import com.lagradost.cloudstream3.utils.AppUtils.tryParseJson
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.URI
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec


class Co4nxtrl : Filesim() {
    override val mainUrl = "https://co4nxtrl.com"
    override val name = "Co4nxtrl"
    override val requiresReferer = true
}


open class Hownetwork : ExtractorApi() {
    override val name = "Hownetwork"
    override val mainUrl = "https://stream.hownetwork.xyz"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ) {
        val id = url.substringAfter("id=")
        val response = app.post(
            "$mainUrl/api2.php?id=$id",
            data = mapOf(
                "r" to "",
                "d" to mainUrl,
            ),
            referer = url,
            headers = mapOf(
                "X-Requested-With" to "XMLHttpRequest"
            )
        ).text
        val json = JSONObject(response)
        val file = json.optString("file")
        callback.invoke(newExtractorLink(
            this.name,
            this.name,
            file,
            type = INFER_TYPE,
            {
                this.referer = file
                this.headers = mapOf(
                    "User-Agent" to "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0",
                    "Accept" to "*/*",
                    "Accept-Language" to "en-US,en;q=0.5",
                    "Sec-GPC" to "1",
                    "Connection" to "keep-alive",
                    "Sec-Fetch-Dest" to "empty",
                    "Sec-Fetch-Mode" to "cors",
                    "Sec-Fetch-Site" to "same-origin",
                    "Priority" to "u=0",
                    "Pragma" to "no-cache",
                    "Cache-Control" to "no-cache",
                    "TE" to "trailers"
                )
            }
        ))
    }
}

class Cloudhownetwork : Hownetwork() {
    override var mainUrl = "https://cloud.hownetwork.xyz"
}

class Furher : Filesim() {
    override val name = "Furher"
    override var mainUrl = "https://furher.in"
}

class Furher2 : Filesim() {
    override val name = "Furher 2"
    override var mainUrl = "723qrh1p.fun"
}

class Turbovidhls : Filesim() {
    override val name = "Turbovidhls"
    override var mainUrl = "https://turbovidhls.com"
}

class Weneverbeenfree : ByseBase() {
    override var name = "Byse"
    override var mainUrl = "https://weneverbeenfree.com"
}

class ByseSayeveum : ByseBase() {
    override var name = "Byse"
    override var mainUrl = "https://f16px.com"
}

open class ByseBase : ExtractorApi() {
    override var name = "Byse"
    override var mainUrl = "https://byse.sx"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit,
    ) {
        val refererUrl = getBaseUrl(url)
        val playbackRoot = getPlayback(url, referer) ?: return
        val streamUrl = decryptPlayback(playbackRoot.playback) ?: return

        val links = M3u8Helper.generateM3u8(
            name,
            streamUrl,
            mainUrl,
            headers = mapOf("Referer" to refererUrl),
        )

        if (links.isNotEmpty()) {
            links.forEach(callback)
        } else {
            callback(
                newExtractorLink(
                    source = name,
                    name = name,
                    url = streamUrl,
                    type = ExtractorLinkType.M3U8,
                ) {
                    this.referer = refererUrl
                    this.quality = Qualities.Unknown.value
                }
            )
        }
    }

    private suspend fun getPlayback(pageUrl: String, referer: String?): PlaybackRoot? {
        val embedBase = getBaseUrl(pageUrl)
        val code = getCodeFromUrl(pageUrl)
        val playbackUrl = "$embedBase/api/videos/$code/embed/playback"
        val headers = getEmbedHeaders(pageUrl, referer)
        val captchaToken = runCatching {
            app.get("$embedBase/api/videos/$code/embed/settings", headers = headers)
                .parsedSafe<ByseSettings>()
                ?.takeIf { it.captchaRequired }
                ?.let { getCaptchaToken(embedBase, code, pageUrl, referer) }
        }.getOrNull()
        val body = """{"fingerprint":{"token":"","viewer_id":"$code","device_id":"$code","confidence":0.1}}"""
        return app.post(
            playbackUrl,
            headers = if (captchaToken.isNullOrBlank()) headers else headers + ("X-Captcha-Token" to captchaToken),
            requestBody = body.toRequestBody("application/json".toMediaTypeOrNull()),
        ).parsedSafe<PlaybackRoot>()
    }

    private suspend fun getCaptchaToken(embedBase: String, code: String, pageUrl: String, referer: String?): String? {
        val headers = getEmbedHeaders(pageUrl, referer)
        val body = """{"fingerprint":{"token":"","viewer_id":"$code","device_id":"$code","confidence":0.1}}"""
        val challenge = app.post(
            "$embedBase/api/videos/$code/embed/captcha",
            headers = headers,
            requestBody = body.toRequestBody("application/json".toMediaTypeOrNull()),
        ).parsedSafe<BysePowChallenge>() ?: return null
        val solution = solvePow(challenge.nonce, challenge.difficulty) ?: return null
        val verifyBody = """{"pow_token":"${challenge.token}","solution":"$solution"}"""
        return app.post(
            "$embedBase/api/videos/$code/embed/captcha/verify",
            headers = headers,
            requestBody = verifyBody.toRequestBody("application/json".toMediaTypeOrNull()),
        ).parsedSafe<BysePowVerify>()?.takeIf { it.status == "ok" }?.token
    }

    private fun getEmbedHeaders(pageUrl: String, referer: String?): Map<String, String> {
        val parentHost = referer?.let { runCatching { URI(it).host }.getOrNull() } ?: getBaseUrl(pageUrl)
        val parentReferer = referer ?: pageUrl
        return mapOf(
            "accept" to "*/*",
            "accept-language" to "en-US,en;q=0.5",
            "content-type" to "application/json",
            "referer" to pageUrl,
            "X-Embed-Origin" to parentHost,
            "X-Embed-Referer" to parentReferer,
            "X-Embed-Parent" to pageUrl,
        )
    }

    private fun decryptPlayback(playback: Playback): String? {
        val keyBytes = buildAesKey(playback)
        val ivBytes = b64UrlDecode(playback.iv)
        val cipherBytes = b64UrlDecode(playback.payload)

        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(keyBytes, "AES"),
            GCMParameterSpec(128, ivBytes),
        )

        var json = String(cipher.doFinal(cipherBytes), StandardCharsets.UTF_8)
        if (json.startsWith("\uFEFF")) json = json.substring(1)
        return tryParseJson<PlaybackDecrypt>(json)?.sources?.firstOrNull()?.url
    }

    private fun buildAesKey(playback: Playback): ByteArray {
        val parts = getVersionedKeyParts(playback)
        return b64UrlDecode(parts[0]) + b64UrlDecode(parts[1])
    }

    private fun getVersionedKeyParts(playback: Playback): List<String> {
        val parts = playback.keyParts
        val version = playback.version?.toIntOrNull()
        val selected = version
            ?.let { listOf(it, 31 - it) }
            ?.mapNotNull { index -> parts.getOrNull(index - 1) }
            ?.filter { it.isNotBlank() }
            .orEmpty()

        return if (selected.size == 2) selected else parts.take(2)
    }

    private fun b64UrlDecode(value: String): ByteArray {
        val fixed = value.replace('-', '+').replace('_', '/')
        val padding = (4 - fixed.length % 4) % 4
        return base64DecodeArray(fixed + "=".repeat(padding))
    }

    private fun getBaseUrl(url: String): String {
        return URI(url).let { "${it.scheme}://${it.host}" }
    }

    private fun getCodeFromUrl(url: String): String {
        val parts = URI(url).path.trim('/').split('/').filter { it.isNotBlank() }
        return when {
            parts.firstOrNull().equals("e", true) && parts.size >= 2 -> parts[1]
            parts.firstOrNull().equals("d", true) && parts.size >= 2 -> parts[1]
            parts.firstOrNull().equals("download", true) && parts.size >= 2 -> parts[1]
            parts.firstOrNull().equals("dwn", true) && parts.size >= 2 -> parts[1]
            parts.size >= 2 && parts[0].length in 3..5 -> parts[1]
            parts.isNotEmpty() -> parts.last()
            else -> ""
        }
    }

    private fun solvePow(nonce: String, difficulty: Int, timeoutMs: Long = 20_000): String? {
        if (difficulty <= 0) return "0"
        val started = System.currentTimeMillis()
        val prefix = "$nonce:"
        var counter = 0
        while (System.currentTimeMillis() - started <= timeoutMs) {
            repeat(1024) {
                if (leadingZeroBits(powHash("$prefix$counter")) >= difficulty) return counter.toString()
                counter++
            }
        }
        Log.w("Byse", "PoW solve timed out for difficulty $difficulty")
        return null
    }

    private fun powHash(value: String): IntArray {
        val state = intArrayOf(1779033703, -1150833019, 1013904242, -1521486534)
        value.forEach { char ->
            state[0] += char.code and 0xff
            state[0] = Integer.rotateLeft(state[0], 7)
            powMix(state)
        }
        repeat(8) { powMix(state) }
        val scratch = IntArray(512)
        repeat(scratch.size) { index ->
            powMix(state)
            scratch[index] = state[0] xor state[2]
        }
        repeat(2) {
            for (index in scratch.indices) {
                val target = scratch[index] and 511
                var current = scratch[index] + scratch[target]
                current = Integer.rotateLeft(current, 13)
                current = current xor (scratch[(index + 1) and 511] * -1640531535)
                scratch[index] = current
                state[0] = state[0] xor current
                powMix(state)
            }
        }
        return IntArray(8) { index ->
            powMix(state)
            var current = state[0]
            val start = index * 64
            for (offset in 0 until 64) {
                val item = scratch[start + offset]
                current += item
                current = Integer.rotateLeft(current, 5)
                current = current xor (item * -2048144777)
            }
            current xor state[2]
        }
    }

    private fun powMix(state: IntArray) {
        state[0] += state[1]
        state[3] = Integer.rotateLeft(state[3] xor state[0], 16)
        state[2] += state[3]
        state[1] = Integer.rotateLeft(state[1] xor state[2], 12)
        state[0] += state[1]
        state[3] = Integer.rotateLeft(state[3] xor state[0], 8)
        state[2] += state[3]
        state[1] = Integer.rotateLeft(state[1] xor state[2], 7)
    }

    private fun leadingZeroBits(values: IntArray): Int {
        var bits = 0
        for (value in values) {
            if (value == 0) {
                bits += 32
            } else {
                return bits + Integer.numberOfLeadingZeros(value)
            }
        }
        return bits
    }
}

data class ByseSettings(
    @param:JsonProperty("captcha_required")
    val captchaRequired: Boolean = false,
)

data class BysePowChallenge(
    @param:JsonProperty("pow_nonce")
    val nonce: String,
    @param:JsonProperty("pow_difficulty")
    val difficulty: Int,
    @param:JsonProperty("pow_token")
    val token: String,
)

data class BysePowVerify(
    val status: String? = null,
    val token: String? = null,
)

data class PlaybackRoot(
    val playback: Playback,
)

data class Playback(
    val iv: String,
    val payload: String,
    val version: String? = null,
    @param:JsonProperty("key_parts")
    val keyParts: List<String>,
)

data class PlaybackDecrypt(
    val sources: List<PlaybackDecryptSource>? = null,
)

data class PlaybackDecryptSource(
    val url: String,
)

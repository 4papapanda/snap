package com.layarKacaProvider

import com.lagradost.api.Log
import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.LoadResponse.Companion.addTrailer
import com.lagradost.cloudstream3.base64DecodeArray
import com.lagradost.cloudstream3.network.CloudflareKiller
import com.lagradost.cloudstream3.network.WebViewResolver
import com.lagradost.cloudstream3.utils.*
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.jsoup.nodes.Element
import java.net.URI
import java.security.MessageDigest


class LayarKacaProvider : MainAPI() {
    companion object {
        var context: android.content.Context? = null
        private const val PLAYER_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:144.0) Gecko/20100101 Firefox/144.0"
        private const val PLAYER_FINGERPRINT =
            "$PLAYER_USER_AGENT|Win32|1920x1080|-420|8"
        private const val PLAYER_XOR_KEY = "Lk21SuksesSelaluJayaJayaJaya!"
        private val playerDecodeKey = intArrayOf(
            74, 185, 216, 24, 163, 156, 120, 0, 9, 25, 251, 102, 77, 24, 122, 23,
            181, 28, 246, 57, 10, 200, 214, 223, 247, 120, 187, 5, 54, 137, 79, 184,
            146, 217, 30, 180, 188, 158, 97, 110, 26, 228, 84, 136, 3, 55, 177, 189,
            34, 89, 36, 169, 128, 63, 89, 192, 103, 137, 50, 43, 209, 213, 26, 194,
            239, 245, 138, 65, 103, 219, 56, 225, 250, 167, 39, 56, 237, 36, 30, 146,
            55, 43, 164, 63, 142, 155, 58, 108, 37, 104, 93, 170, 208, 28, 184, 222,
            198, 192, 218, 204
        )
    }
    override var mainUrl = "https://lk21.de"
    private var seriesUrl = "https://series.lk21.de"
    private var searchurl= "https://gudangvape.com"
    private val cloudflareInterceptor by lazy { CloudflareKiller() }

    override var name = "LayarKaca🎞"
    override val hasMainPage = true
    override var lang = "id"
    override val supportedTypes = setOf(
        TvType.Movie,
        TvType.TvSeries,
        TvType.AsianDrama
    )


    override val mainPage = mainPageOf(
        "$mainUrl/populer/page/" to "Film Terplopuler",
        "$mainUrl/rating/page/" to "Film Berdasarkan IMDb Rating",
        "$mainUrl/most-commented/page/" to "Film Dengan Komentar Terbanyak",
        "$seriesUrl/latest-series/page/" to "Series Terbaru",
        "$seriesUrl/series/asian/page/" to "Film Asian Terbaru",
        "$mainUrl/latest/page/" to "Film Upload Terbaru",
    )

    override suspend fun getMainPage(
        page: Int,
        request: MainPageRequest
    ): HomePageResponse {
        val document = app.get(request.data + page).document
        val home = document.select("article figure").mapNotNull {
            it.toSearchResult()
        }
        return newHomePageResponse(request.name, home)
    }

    private suspend fun getProperLink(url: String): String {
        if (url.startsWith(seriesUrl)) return url
        val res = app.get(url).document
        return if (res.select("title").text().contains("Nontondrama", true)) {
            res.selectFirst("a#openNow")?.attr("href")
                ?: res.selectFirst("div.links a")?.attr("href")
                ?: url
        } else {
            url
        }
    }


    private fun Element.toSearchResult(): SearchResponse? {
        val title = this.selectFirst("h3")?.ownText()?.trim() ?: return null
        val href = fixUrl(this.selectFirst("a")!!.attr("href"))
        val posterUrl = fixUrlNull(this.selectFirst("img")?.getImageAttr())
        val ratingText = selectFirst("span.rating")?.ownText()?.trim()
        val type = if (this.selectFirst("span.episode") == null) TvType.Movie else TvType.TvSeries
        val posterheaders= mapOf("Referer" to getBaseUrl(posterUrl))
        return if (type == TvType.TvSeries) {
            val episode = this.selectFirst("span.episode strong")?.text()?.filter { it.isDigit() }
                ?.toIntOrNull()
            newAnimeSearchResponse(title, href, TvType.TvSeries) {
                this.posterUrl = posterUrl
                this.posterHeaders = posterheaders
                addSub(episode)
                this.score = Score.from10(ratingText?.toDoubleOrNull())
            }
        } else {
            val quality = this.select("div.quality").text().trim()
            newMovieSearchResponse(title, href, TvType.Movie) {
                this.posterUrl = posterUrl
                this.posterHeaders = posterheaders
                addQuality(quality)
                this.score = Score.from10(ratingText?.toDoubleOrNull())
            }
        }
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val refer = app.get(mainUrl).url
        val res = app.get("$searchurl/search.php?s=$query", referer = refer).text
        val results = mutableListOf<SearchResponse>()

        val root = JSONObject(res)
        val arr = root.getJSONArray("data")

        for (i in 0 until arr.length()) {
            val item = arr.getJSONObject(i)
            val title = item.getString("title")
            val slug = item.getString("slug")
            val type = item.getString("type")
            val posterUrl = "https://static-jpg.lk21.party/wp-content/uploads/"+item.optString("poster")
            when (type) {
                "series" -> results.add(
                    newTvSeriesSearchResponse(title, "$seriesUrl/$slug", TvType.TvSeries) {
                        this.posterUrl = posterUrl
                    }
                )
                "movie" -> results.add(
                    newMovieSearchResponse(title, "$mainUrl/$slug", TvType.Movie) {
                        this.posterUrl = posterUrl
                    }
                )
            }
        }

        return results
    }

    override suspend fun load(url: String): LoadResponse {
        val fixUrl = getProperLink(url)
        val document = app.get(fixUrl).document
        val baseurl=fetchURL(fixUrl)
        val title = document.selectFirst("div.movie-info h1")?.text()?.trim().toString()
        val poster = document.select("meta[property=og:image]").attr("content")
        val tags = document.select("div.tag-list span").map { it.text() }
        val posterheaders= mapOf("Referer" to getBaseUrl(poster))

        val year = Regex("\\d, (\\d+)").find(
            document.select("div.movie-info h1").text().trim()
        )?.groupValues?.get(1).toString().toIntOrNull()
        val tvType = if (document.selectFirst("#season-data") != null) TvType.TvSeries else TvType.Movie
        val description = document.selectFirst("div.meta-info")?.text()?.trim()
        val trailer = document.selectFirst("ul.action-left > li:nth-child(3) > a")?.attr("href")
        val rating = document.selectFirst("div.info-tag strong")?.text()

        val recommendations = document.select("li.slider article").map {
            val recName = it.selectFirst("h3")?.text()?.trim().toString()
            val recHref = baseurl+it.selectFirst("a")!!.attr("href")
            val recPosterUrl = fixUrl(it.selectFirst("img")?.attr("src").toString())
            newTvSeriesSearchResponse(recName, recHref, TvType.TvSeries) {
                this.posterUrl = recPosterUrl
                this.posterHeaders = posterheaders
            }
        }

        return if (tvType == TvType.TvSeries) {
            val json = document.selectFirst("script#season-data")?.data()
            val episodes = mutableListOf<Episode>()
            if (json != null) {
                val root = JSONObject(json)
                root.keys().forEach { seasonKey ->
                    val seasonArr = root.getJSONArray(seasonKey)
                    for (i in 0 until seasonArr.length()) {
                        val ep = seasonArr.getJSONObject(i)
                        val href = fixUrl("$baseurl/"+ep.getString("slug"))
                        val episodeNo = ep.optInt("episode_no")
                        val seasonNo = ep.optInt("s")
                        episodes.add(
                            newEpisode(href) {
                                this.name = "Episode $episodeNo"
                                this.season = seasonNo
                                this.episode = episodeNo
                            }
                        )
                    }
                }
            }
            newTvSeriesLoadResponse(title, url, TvType.TvSeries, episodes) {
                this.posterUrl = poster
                this.posterHeaders = posterheaders
                this.year = year
                this.plot = description
                this.tags = tags
                this.score = Score.from10(rating)
                this.recommendations = recommendations
                addTrailer(trailer)
            }
        } else {
            newMovieLoadResponse(title, url, TvType.Movie, url) {
                this.posterUrl = poster
                this.posterHeaders = posterheaders
                this.year = year
                this.plot = description
                this.tags = tags
                this.score = Score.from10(rating)
                this.recommendations = recommendations
                addTrailer(trailer)
            }
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val pageUrl = getProperLink(data)
        val pageResponse = runCatching {
            app.get(
                pageUrl,
                interceptor = cloudflareInterceptor,
                headers = mapOf("User-Agent" to PLAYER_USER_AGENT),
            )
        }.getOrElse { app.get(pageUrl) }
        val resolvedPageUrl = pageResponse.url
        val document = pageResponse.document
        val emitted = mutableSetOf<String>()
        val wrappedCallback: (ExtractorLink) -> Unit = { link ->
            if (emitted.add(link.url)) callback(link)
        }

        val playerCandidates = mutableListOf<String>()
        Regex("""firstStreamingUrl\s*=\s*['"]?([^'";\s]+)""")
            .find(pageResponse.text)
            ?.groupValues
            ?.getOrNull(1)
            ?.takeIf { it.isNotBlank() }
            ?.let(playerCandidates::add)

        document.select("ul#player-list a").forEach { video ->
            video.attr("data-url").takeIf { it.isNotBlank() }?.let(playerCandidates::add)
            video.attr("href").takeIf { it.isNotBlank() && it != "#" }?.let { playerCandidates.add(fixUrl(it)) }
        }

        playerCandidates.distinct().forEach { candidate ->
            val player = decodeCurrentPlayerToken(candidate)
                ?: resolveProtectedPlayer(candidate, resolvedPageUrl)
                ?: decodePlayerToken(candidate)?.let { decoded -> "$decoded/embed" }
                ?: candidate.takeIf { it.startsWith("http://") || it.startsWith("https://") }
                ?: return@forEach

            val iframe = resolvePlayerIframe(player, resolvedPageUrl) ?: player
            val fixedIframe = if (iframe.contains("https://short.icu", true)) {
                app.get(iframe, allowRedirects = true).url
            } else {
                iframe
            }

            loadDirectPlayer(fixedIframe, player, wrappedCallback)
            loadExtractor(fixedIframe, resolvedPageUrl, subtitleCallback, wrappedCallback)
        }

        if (emitted.isEmpty()) {
            loadWebViewPlayer(resolvedPageUrl, wrappedCallback)
        }

        return emitted.isNotEmpty()
    }

    private suspend fun loadWebViewPlayer(
        pageUrl: String,
        callback: (ExtractorLink) -> Unit,
    ) {
        val mediaRegex = Regex("""https?://[^"'\s]+?\.(?:m3u8|mp4)(?:\?[^"'\s]*)?""", RegexOption.IGNORE_CASE)
        val mediaUrl = runCatching {
            app.get(
                pageUrl,
                headers = mapOf("User-Agent" to PLAYER_USER_AGENT),
                interceptor = WebViewResolver(
                    interceptUrl = mediaRegex,
                    additionalUrls = listOf(mediaRegex),
                    useOkhttp = false,
                    timeout = 45_000L,
                ),
                timeout = 60L,
            ).url.substringBefore("#")
        }.getOrNull()
            ?.takeIf { isValidVideoUrl(it) }
            ?: return

        emitMedia("LayarKaca WebView", mediaUrl, pageUrl, callback)
    }

    private fun isValidVideoUrl(url: String): Boolean {
        if (!url.contains(".m3u8", true) && !url.contains(".mp4", true)) return false

        val host = runCatching { URI(url).host.orEmpty().lowercase() }.getOrDefault("")
        if (host.isBlank()) return false

        val blockedHosts = listOf(
            "organicowner.com",
            "fractionfridgejudiciary.com",
            "endedstrung.com",
            "purposeparking.com",
            "acreageupwhirl.com",
            "toodlerehouse.com",
            "juicyads.com",
            "histats.com",
            "google.com",
            "googletagmanager.com",
            "google-analytics.com",
            "cloudflareinsights.com",
            "playeriframe.sbs",
            "playeriframe.lol",
            "lk21.de",
            "lk21official.cc",
        )
        if (blockedHosts.any { host == it || host.endsWith(".$it") }) return false

        val allowedHosts = listOf(
            "hownetwork.xyz",
            "turboviplay.com",
            "sptvp.com",
            "abysscdn.com",
            "abyssplayer.com",
            "player-cdn.com",
            "weneverbeenfree.com",
            "emturbovid.com",
            "turbovidhls.com",
            "vidhide",
            "short.icu",
        )
        return allowedHosts.any { host.contains(it) }
    }

    private suspend fun loadDirectPlayer(
        url: String,
        referer: String,
        callback: (ExtractorLink) -> Unit,
    ) {
        if (url.contains("hownetwork.xyz", true)) {
            val id = URI(url).rawQuery
                ?.split("&")
                ?.firstOrNull { it.substringBefore("=") == "id" }
                ?.substringAfter("=")
                ?.takeIf { it.isNotBlank() }
                ?: return
            val base = getBaseUrl(url)
            val json = runCatching {
                JSONObject(
                    app.post(
                        "$base/api2.php?id=$id",
                        data = mapOf("r" to "", "d" to base),
                        referer = url,
                        headers = mapOf("X-Requested-With" to "XMLHttpRequest"),
                    ).text
                )
            }.getOrNull() ?: return
            val file = json.optString("file").takeIf { it.isNotBlank() } ?: return
            emitMedia("Hownetwork", file, url, callback)
            return
        }

        val page = runCatching { app.get(url, referer = referer).document }.getOrNull() ?: return
        val scripts = page.select("script").joinToString("\n") { it.data() }
        val file = page.selectFirst("#video_player[data-hash]")?.attr("data-hash")?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: Regex("""var\s+urlPlay\s*=\s*['"]([^'"]+)['"]""")
                .find(scripts)
                ?.groupValues
                ?.getOrNull(1)
                ?.trim()
                ?.takeIf { it.isNotBlank() }
            ?: Regex("""["'](https?://[^"']+\.m3u8[^"']*)["']""")
                .find(scripts)
                ?.groupValues
                ?.getOrNull(1)
                ?.trim()
                ?.takeIf { it.isNotBlank() }
            ?: return

        val fixedFile = fixPlayerUrl(file, url)
        emitMedia(getBaseUrl(url).substringAfter("://"), fixedFile, url, callback)
    }

    private suspend fun emitMedia(
        source: String,
        streamUrl: String,
        referer: String,
        callback: (ExtractorLink) -> Unit,
    ) {
        val headers = mapOf("User-Agent" to PLAYER_USER_AGENT, "Referer" to referer)
        if (!isValidVideoUrl(streamUrl)) return

        if (!streamUrl.contains(".m3u8", true)) {
            callback(
                newExtractorLink(
                    source = source,
                    name = source,
                    url = streamUrl,
                    type = INFER_TYPE,
                ) {
                    this.referer = referer
                    this.headers = headers
                }
            )
            return
        }

        val links = M3u8Helper.generateM3u8(
            source,
            streamUrl,
            referer,
            headers = headers,
        )

        if (links.isNotEmpty()) {
            links.forEach(callback)
        } else {
            callback(
                newExtractorLink(
                    source = source,
                    name = source,
                    url = streamUrl,
                    type = ExtractorLinkType.M3U8,
                ) {
                    this.referer = referer
                    this.headers = headers
                    this.quality = Qualities.Unknown.value
                }
            )
        }
    }

    private suspend fun resolveProtectedPlayer(token: String, pageUrl: String): String? {
        val playerHost = getSintaHost(pageUrl) ?: return null
        val origin = getBaseUrl(pageUrl)
        val headers = mapOf(
            "Origin" to origin,
            "Referer" to pageUrl,
            "User-Agent" to PLAYER_USER_AGENT,
        )

        val challengeResponse = runCatching {
            app.get(
                "$playerHost/challenge.php?id=$token",
                referer = pageUrl,
                headers = headers,
            )
        }.getOrNull() ?: return null
        val challenge = runCatching { JSONObject(challengeResponse.text) }.getOrNull() ?: return null

        challenge.optString("url").takeIf { it.isNotBlank() }?.let { return it }
        if (!challenge.optBoolean("success")) return null

        val challengeText = challenge.optString("challenge").takeIf { it.isNotBlank() } ?: return null
        val difficulty = challenge.optInt("difficulty", 0).coerceAtMost(8)
        val nonce = solvePow(challengeText, difficulty) ?: return null
        val body = JSONObject()
            .put("challenge", challengeText)
            .put("nonce", nonce)
            .put("id", token)
            .put("fp", PLAYER_FINGERPRINT)
            .toString()

        val verify = runCatching {
            JSONObject(
                app.post(
                    "$playerHost/verify.php",
                    referer = pageUrl,
                    headers = headers + ("Content-Type" to "application/json"),
                    cookies = challengeResponse.cookies,
                    requestBody = body.toRequestBody("application/json".toMediaTypeOrNull()),
                ).text
            )
        }.getOrNull() ?: return null

        return verify.optString("url").takeIf { verify.optBoolean("success") && it.isNotBlank() }
    }

    private fun solvePow(challenge: String, difficulty: Int): Int? {
        if (difficulty <= 0) return 0
        val prefix = "0".repeat(difficulty)
        val digest = MessageDigest.getInstance("SHA-256")

        for (nonce in 0..5_000_000) {
            val hash = digest.digest("$challenge$nonce".toByteArray()).toHex()
            if (hash.startsWith(prefix)) return nonce
        }

        return null
    }

    private fun ByteArray.toHex(): String {
        return joinToString("") { "%02x".format(it) }
    }

    private fun getSintaHost(url: String): String? {
        val host = runCatching { URI(url).host }.getOrNull() ?: return null
        val root = host.split(".").takeLast(2).joinToString(".")
        return "https://sinta.$root"
    }

    private suspend fun resolvePlayerIframe(player: String, referer: String): String? {
        val document = runCatching {
            app.get(player, referer = referer).document
        }.getOrNull() ?: return null

        return document.select("div.embed-container iframe[src], iframe[src]")
            .mapNotNull { it.attr("src").takeIf(String::isNotBlank) }
            .firstOrNull { !it.contains("google.com", true) }
            ?.let { fixPlayerUrl(it, player) }
    }

    private fun decodePlayerToken(token: String): String? {
        val bytes = runCatching { base64DecodeArray(token) }.getOrNull() ?: return null
        if (bytes.isEmpty() || bytes.size > playerDecodeKey.size) return null

        return buildString {
            bytes.forEachIndexed { index, byte ->
                val previous = if (index == 0) 0 else bytes[index - 1].toInt() and 0xff
                val decoded = (byte.toInt() and 0xff) xor previous xor playerDecodeKey[index]
                append(decoded.toChar())
            }
        }.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    private fun decodeCurrentPlayerToken(token: String): String? {
        val bytes = runCatching { base64DecodeArray(token) }.getOrNull() ?: return null
        if (bytes.isEmpty()) return null

        return buildString {
            bytes.forEachIndexed { index, byte ->
                val decoded = (byte.toInt() and 0xff) xor PLAYER_XOR_KEY[index % PLAYER_XOR_KEY.length].code
                append(decoded.toChar())
            }
        }.takeIf { it.startsWith("http://") || it.startsWith("https://") }
    }

    private fun fixPlayerUrl(url: String, base: String): String {
        return when {
            url.startsWith("//") -> "https:$url"
            url.startsWith("/") -> "${getBaseUrl(base)}$url"
            url.startsWith("http://") || url.startsWith("https://") -> url
            else -> "${base.substringBeforeLast("/")}/$url"
        }
    }


    private suspend fun String.getIframe(): String {
        return app.get(this, referer = "$seriesUrl/").document.select("div.embed-container iframe")
            .attr("src")
    }

    private suspend fun fetchURL(url: String): String {
        val res = app.get(url, allowRedirects = false)
        val href = res.headers["location"]

        return if (href != null) {
            val it = URI(href)
            "${it.scheme}://${it.host}"
        } else {
            url
        }
    }


    private fun Element.getImageAttr(): String {
        return when {
            this.hasAttr("src") -> this.attr("src")
            this.hasAttr("data-src") -> this.attr("data-src")
            else -> this.attr("src")
        }
    }


    fun getBaseUrl(url: String?): String {
        return URI(url).let {
            "${it.scheme}://${it.host}"
        }
    }

}

package com.melongmovie

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.LoadResponse.Companion.addActors
import com.lagradost.cloudstream3.LoadResponse.Companion.addScore
import com.lagradost.cloudstream3.LoadResponse.Companion.addTrailer
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.mainPageOf
import com.lagradost.cloudstream3.network.CloudflareKiller
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.httpsify
import com.lagradost.cloudstream3.utils.loadExtractor
import com.lagradost.nicehttp.NiceResponse
import okhttp3.Interceptor
import okhttp3.Response
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import org.jsoup.Jsoup
import org.jsoup.nodes.Element


class Melongmovie : MainAPI() {
    companion object {
        var context: android.content.Context? = null
        @Volatile private var cfCookieHeader: String? = null

        const val LIST_TIMEOUT_SECONDS = 90L
        const val DEFAULT_TIMEOUT_SECONDS = 75L

        private fun updateCfCookieHeader(cookies: Map<String, String>) {
            if (cookies.isEmpty()) return
            val filtered = cookies.filterKeys { it == "cf_clearance" || it == "__cf_bm" }
            if (filtered.isEmpty()) return
            cfCookieHeader = filtered.entries.joinToString("; ") { (k, v) -> "$k=$v" }
        }

        private fun updateCfCookieHeader(rawCookie: String?) {
            if (rawCookie.isNullOrBlank()) return
            val filtered = rawCookie.split(";")
                .map { it.trim() }
                .filter { it.startsWith("cf_clearance=") || it.startsWith("__cf_bm=") }
            if (filtered.isNotEmpty()) cfCookieHeader = filtered.joinToString("; ")
        }
    }
    override var mainUrl = "https://tv12.melongmovies.com"
    private var directUrl: String? = null
    override var name = "Melongmovie"
    override val hasMainPage = true
    override var lang = "id"
    override val supportedTypes =
            setOf(TvType.Movie)

    private val cloudflareInterceptor by lazy { CloudflareKiller() }
    private val turnstileInterceptor by lazy { MelongmovieTurnstileInterceptor() }
    private val defaultHeaders = mapOf(
        "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
        "Accept-Language" to "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control" to "no-cache",
        "Pragma" to "no-cache",
        "Upgrade-Insecure-Requests" to "1",
        "User-Agent" to "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Mobile Safari/537.36"
    )

    override val mainPage = mainPageOf(
    "/latest-movies/page/%d/" to "Movie Terbaru",
    "/advanced-search/page/%d/?order=latest&country%%5B%%5D=china&type%%5B%%5D=post" to "Movie China",
    "/advanced-search/page/%d/?order=latest&country%%5B%%5D=hong-kong&type%%5B%%5D=post" to "Movie Hongkong",
    "/advanced-search/page/%d/?order=latest&country%%5B%%5D=india&type%%5B%%5D=post" to "Movie India",
    "/advanced-search/page/%d/?order=latest&country%%5B%%5D=japan&type%%5B%%5D=post" to "Movie Jepang",
)


 override suspend fun getMainPage(
    page: Int,
    request: MainPageRequest
): HomePageResponse {
    val safePage = if (page <= 0) 1 else page
    val url = request.data.format(safePage)

    val document = runCatching {
        requestPage(url, timeoutSeconds = LIST_TIMEOUT_SECONDS).document
    }.getOrNull() ?: return newHomePageResponse(
        HomePageList(request.name, emptyList()),
        hasNext = false
    )
    val items = document.select(searchResultSelector)
        .mapNotNull { it.toSearchResult() }
        .filterNot { it.url.isSeriesUrl() }

    return newHomePageResponse(
        HomePageList(request.name, items),
        hasNext = items.isNotEmpty()
    )
}


    private fun Element.toSearchResult(): SearchResponse? {
    val linkElement = this.selectFirst("a") ?: return null
    val href = fixUrl(linkElement.attr("href"))
    val title = linkElement.attr("title")
        .ifBlank { this.selectFirst("h2.entry-title")?.text() }
        ?: return null

    val poster = this.selectFirst("img")?.getImageAttr()?.let { fixUrlNull(it) }
    val quality = this.selectFirst("span.quality")?.text()?.trim()

    if (href.isSeriesUrl() || title.isSeriesTitle()) return null

    return newMovieSearchResponse(title, href, TvType.Movie) {
        this.posterUrl = poster
        this.quality = getQualityFromString(quality)
    }
}


    override suspend fun search(query: String): List<SearchResponse> {
    val document = runCatching {
        requestPage("$mainUrl/?s=$query", timeoutSeconds = LIST_TIMEOUT_SECONDS).document
    }.getOrNull() ?: return emptyList()
    return document.select(searchResultSelector)
        .mapNotNull { it.toSearchResult() }
        .filterNot { it.url.isSeriesUrl() }
}


    private fun Element.toRecommendResult(): SearchResponse? {
    val href = this.selectFirst("a.tip")?.attr("href") ?: return null
    val img = this.selectFirst("a.tip img")

    val title = img?.attr("alt")?.trim() ?: return null
    val posterUrl = fixUrlNull(img?.getImageAttr()?.fixImageQuality())

    return newMovieSearchResponse(title, href, TvType.Movie) {
        this.posterUrl = posterUrl
    }
}


    override suspend fun load(url: String): LoadResponse {
    val doc = runCatching { requestPage(url).document }.getOrNull()
        ?: return newMovieLoadResponse(titleFromUrl(url), url, TvType.Movie, null)

    val title = doc.selectFirst("h1.entry-title")?.text()?.trim().orEmpty()
    val poster = fixUrlNull(doc.selectFirst("div.limage img")?.getImageAttr())
    val description = doc.selectFirst("div.bixbox > p")?.text()?.trim() // sinopsis
    val year = doc.selectFirst("ul.data li:has(b:contains(Release))")?.text()
        ?.filter { it.isDigit() }?.take(4)?.toIntOrNull()

    val tags = doc.select("ul.data li:has(b:contains(Genre)) a").map { it.text() }
    val actors = doc.select("ul.data li:has(b:contains(Stars)) a").map { it.text() }
    val rating = doc.selectFirst("span[itemprop=ratingValue], span.ratingValue")?.text()
    val trailer = doc.select("ul.mirror li.li-sora-trailer a[data-em], ul.mirror li a:matchesOwn((?i)^\\s*Trailer\\s*$)")
        .asSequence()
        .mapNotNull { it.getDataEmIframeUrl() }
        .firstOrNull { it.isTrailerUrl() }
    val duration = doc.selectFirst("span[property=duration]")
    ?.text()
    ?.replace(Regex("\\D"), "")
    ?.toIntOrNull()
    val recommendations = doc.select("div.latest.relat article.box")
        .mapNotNull { it.toRecommendResult() }

    return newMovieLoadResponse(title, url, TvType.Movie, url) {
        this.posterUrl = poster
        this.year = year
        this.plot = description
        this.tags = tags
        addActors(actors)
        addScore(rating)
        trailer?.let { addTrailer(it) }
        this.recommendations = recommendations
        this.duration = duration ?: 0
    }
}


override suspend fun loadLinks(
    data: String,
    isCasting: Boolean,
    subtitleCallback: (SubtitleFile) -> Unit,
    callback: (ExtractorLink) -> Unit
): Boolean {
    val parts = data.split("#")
    val url = parts[0]
    var found = false

    val doc = requestPage(url).document

    doc.select("div#embed_holder iframe").forEach { iframe ->
        val src = iframe.getIframeAttr().orEmpty()
        if (src.isNotBlank() && !src.isTrailerUrl()) {
            loadExtractor(src, url, subtitleCallback, callback)
            found = true
        }
    }

    doc.select("ul.mirror li a[data-href]").forEach { a ->
        if (a.isTrailerMirror()) return@forEach
        val mirrorUrl = a.attr("data-href")
        val mirrorDoc = requestPage(mirrorUrl, referer = url).document
        val iframe = mirrorDoc.selectFirst("div#embed_holder iframe")?.getIframeAttr()
        if (iframe != null && !iframe.isTrailerUrl()) {
            loadExtractor(iframe, mirrorUrl, subtitleCallback, callback)
            found = true
        }
    }

    return found
}

    private suspend fun requestPage(
        url: String,
        referer: String? = "$mainUrl/",
        timeoutSeconds: Long = DEFAULT_TIMEOUT_SECONDS
    ): NiceResponse {
        val fixedUrl = fixRequestUrl(url)
        val fixedReferer = referer?.let(::fixRequestUrl)
        val first = app.get(
            fixedUrl,
            interceptor = cloudflareInterceptor,
            headers = defaultHeaders + cookieHeader(),
            referer = fixedReferer,
            timeout = timeoutSeconds
        )
        updateCfCookieHeader(first.cookies)
        mainUrl = runCatching { getBaseUrl(first.url) }.getOrDefault(mainUrl)

        if (!isUsableResponse(first)) {
            val second = app.get(
                fixedUrl,
                interceptor = turnstileInterceptor,
                headers = defaultHeaders + cookieHeader(),
                referer = fixedReferer,
                timeout = timeoutSeconds
            )
            updateCfCookieHeader(second.cookies)
            mainUrl = runCatching { getBaseUrl(second.url) }.getOrDefault(mainUrl)
            if (isUsableResponse(second)) return second
            error("Melongmovie request blocked or failed: $fixedUrl")
        }

        return first
    }

    private fun isUsableResponse(response: NiceResponse): Boolean {
        if (response.code == 403 || response.code == 429 || response.code == 503) return false
        return !looksLikeCloudflareChallenge(response.text)
    }

    private fun fixRequestUrl(url: String): String {
        return when {
            url.startsWith("http", true) -> url
            url.startsWith("//") -> "https:$url"
            url.startsWith("/") -> "$mainUrl$url"
            else -> "$mainUrl/$url"
        }
    }

    private fun cookieHeader(): Map<String, String> {
        val cookie = cfCookieHeader.orEmpty()
        return if (cookie.isBlank()) emptyMap() else mapOf("Cookie" to cookie)
    }

    private fun looksLikeCloudflareChallenge(html: String?): Boolean {
        val preview = html?.take(128 * 1024).orEmpty()
        if (preview.isBlank()) return false
        val hints = listOf(
            "cf-challenge",
            "cf-browser-verification",
            "challenge-platform",
            "Performing security verification",
            "Verifying you are human",
            "Just a moment",
            "Attention Required",
            "/cdn-cgi/challenge-platform/"
        )
        return hints.any { preview.contains(it, ignoreCase = true) }
    }

    private val searchResultSelector = "div.los article.box, article.box, div.latest article.box, div.listupd article, article"

    private fun String.isSeriesUrl(): Boolean {
        val lower = lowercase()
        return lower.contains("/series/") ||
            lower.contains("/tv-series/") ||
            lower.contains("/episode/") ||
            lower.contains("/watch/") ||
            Regex("""(?i)(?:^|[-/])s\d+(?:[-/]|$)""").containsMatchIn(this) ||
            Regex("""(?i)(?:^|[-/])season[-/]?\d*(?:[-/]|$)""").containsMatchIn(this)
    }

    private fun String.isSeriesTitle(): Boolean {
        return Regex("""(?i)\b(?:season|series|episode|eps?|s\d{1,2})\b""").containsMatchIn(this)
    }

    private fun Element.getImageAttr(): String {
        return when {
            this.hasAttr("data-src") -> this.attr("abs:data-src")
            this.hasAttr("data-lazy-src") -> this.attr("abs:data-lazy-src")
            this.hasAttr("srcset") -> this.attr("abs:srcset").substringBefore(" ")
            else -> this.attr("abs:src")
        }
    }

    private fun Element?.getIframeAttr(): String? {
        return this?.attr("data-litespeed-src").takeIf { it?.isNotEmpty() == true }
                ?: this?.attr("data-src").takeIf { it?.isNotEmpty() == true }
                ?: this?.attr("src")
    }

    private fun Element.getDataEmIframeUrl(): String? {
        val encoded = attr("data-em").trim()
        if (encoded.isBlank()) return null
        val decoded = runCatching {
            String(Base64.decode(encoded, Base64.DEFAULT), Charsets.UTF_8)
        }.getOrNull() ?: return null
        return Jsoup.parse(decoded).selectFirst("iframe")?.getIframeAttr()?.normalizeProtocol()
    }

    private fun Element.isTrailerMirror(): Boolean {
        return parent()?.hasClass("li-sora-trailer") == true ||
            text().contains("trailer", ignoreCase = true) ||
            getDataEmIframeUrl()?.isTrailerUrl() == true
    }

    private fun String.normalizeProtocol(): String {
        return when {
            startsWith("//") -> "https:$this"
            else -> this
        }
    }

    private fun String.isTrailerUrl(): Boolean {
        val normalized = normalizeProtocol().lowercase()
        return normalized.contains("youtube.com/embed/") ||
            normalized.contains("youtube.com/watch") ||
            normalized.contains("youtu.be/") ||
            normalized.contains("youtube-nocookie.com/embed/")
    }

    private fun String?.fixImageQuality(): String? {
        if (this == null) return null
        val regex = Regex("(-\\d*x\\d*)").find(this)?.groupValues?.get(0) ?: return this
        return this.replace(regex, "")
    }

    private fun titleFromUrl(url: String): String =
        url.trimEnd('/')
            .substringAfterLast("/")
            .replace("-", " ")
            .trim()
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
            .ifBlank { name }

    private fun getBaseUrl(url: String): String {
        return URI(url).let { "${it.scheme}://${it.host}" }
    }
}

class MelongmovieTurnstileInterceptor(
    private val targetCookies: List<String> = listOf("cf_clearance", "__cf_bm")
) : Interceptor {
    companion object {
        private const val POLL_INTERVAL_MS = 500L
        private const val MAX_ATTEMPTS = 60
        private const val PAGE_WAIT_SECONDS = 30L
        private val clearanceCache = ConcurrentHashMap<String, Long>()
    }

    private fun getCookieHeader(url: String, domainUrl: String): String {
        val manager = CookieManager.getInstance()
        return manager.getCookie(url) ?: manager.getCookie(domainUrl) ?: ""
    }

    private fun getCookieValue(url: String, domainUrl: String): String? {
        val raw = getCookieHeader(url, domainUrl)
        if (raw.isBlank()) return null
        return raw.split(";")
            .map { it.trim() }
            .firstNotNullOfOrNull { cookie ->
                targetCookies.firstOrNull { target -> cookie.startsWith("$target=") }
                    ?.let { cookie.substringAfter("=") }
                    ?.takeIf { it.isNotBlank() }
            }
    }

    private fun invalidateCookie(domainUrl: String) {
        CookieManager.getInstance().apply {
            targetCookies.forEach { cookie ->
                setCookie(domainUrl, "$cookie=; Max-Age=0")
            }
            flush()
        }
    }

    private fun hasChallenge(response: Response): Boolean {
        if (response.code == 403 || response.code == 429 || response.code == 503) return true

        val contentType = response.header("Content-Type").orEmpty()
        if (!contentType.contains("text/html", ignoreCase = true)) return false

        val preview = runCatching { response.peekBody(128 * 1024).string() }.getOrDefault("")
        if (preview.isBlank()) return false

        val challengeHints = listOf(
            "cf-challenge",
            "cf-browser-verification",
            "cf_clearance",
            "challenge-platform",
            "Performing security verification",
            "Verifying you are human",
            "Just a moment",
            "Attention Required",
            "/cdn-cgi/challenge-platform/"
        )
        return challengeHints.any { preview.contains(it, ignoreCase = true) }
    }

    private fun hasFreshClearance(url: String, domainUrl: String): Boolean {
        val hasCookie = getCookieValue(url, domainUrl) != null
        if (!hasCookie) {
            clearanceCache.remove(domainUrl)
            return false
        }
        val lastSolved = clearanceCache[domainUrl] ?: return true
        return System.currentTimeMillis() - lastSolved < TimeUnit.MINUTES.toMillis(20)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val url = originalRequest.url.toString()
        val domainUrl = "${originalRequest.url.scheme}://${originalRequest.url.host}"
        val cookieManager = CookieManager.getInstance()

        if (hasFreshClearance(url, domainUrl)) {
            val response = chain.proceed(
                originalRequest.newBuilder()
                    .header("Cookie", getCookieHeader(url, domainUrl))
                    .build()
            )
            if (!hasChallenge(response)) {
                clearanceCache[domainUrl] = System.currentTimeMillis()
                return response
            }
            response.close()
            invalidateCookie(domainUrl)
            clearanceCache.remove(domainUrl)
        }

        val context = Melongmovie.context
            ?: return chain.proceed(originalRequest)

        val handler = Handler(Looper.getMainLooper())
        var webView: WebView? = null
        var resolvedUserAgent = originalRequest.header("User-Agent") ?: ""
        val challengeLatch = CountDownLatch(1)

        handler.post {
            try {
                val wv = WebView(context).also { webView = it }
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
                wv.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    javaScriptCanOpenWindowsAutomatically = true
                    loadsImagesAutomatically = true
                    if (resolvedUserAgent.isNotBlank()) userAgentString = resolvedUserAgent
                    resolvedUserAgent = userAgentString
                }
                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, finishedUrl: String) {
                        super.onPageFinished(view, finishedUrl)
                        cookieManager.flush()
                        if (getCookieValue(finishedUrl, domainUrl) != null) {
                            clearanceCache[domainUrl] = System.currentTimeMillis()
                            challengeLatch.countDown()
                        }
                    }
                }
                wv.loadUrl(url)
            } catch (e: Exception) {
                challengeLatch.countDown()
                e.printStackTrace()
            }
        }

        challengeLatch.await(PAGE_WAIT_SECONDS, TimeUnit.SECONDS)

        var attempts = 0
        while (attempts < MAX_ATTEMPTS && getCookieValue(url, domainUrl) == null) {
            Thread.sleep(POLL_INTERVAL_MS)
            cookieManager.flush()
            attempts++
        }

        if (getCookieValue(url, domainUrl) != null) {
            clearanceCache[domainUrl] = System.currentTimeMillis()
        }

        handler.post {
            try {
                webView?.apply {
                    stopLoading()
                    clearCache(false)
                    destroy()
                }
                webView = null
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val finalCookies = getCookieHeader(url, domainUrl)
        val finalResponse = chain.proceed(
            originalRequest.newBuilder()
                .header("Cookie", finalCookies)
                .apply { if (resolvedUserAgent.isNotBlank()) header("User-Agent", resolvedUserAgent) }
                .build()
        )

        if (!hasChallenge(finalResponse)) {
            clearanceCache[domainUrl] = System.currentTimeMillis()
            return finalResponse
        }

        clearanceCache.remove(domainUrl)
        return finalResponse
    }
}

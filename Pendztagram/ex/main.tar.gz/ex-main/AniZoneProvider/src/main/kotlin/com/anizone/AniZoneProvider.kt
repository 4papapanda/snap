package com.anizone

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.LoadResponse.Companion.addAniListId
import com.lagradost.cloudstream3.LoadResponse.Companion.addMalId
import com.lagradost.cloudstream3.USER_AGENT
import com.lagradost.cloudstream3.newSubtitleFile
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import com.lagradost.cloudstream3.utils.newExtractorLink
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URLEncoder

class AniZoneProvider : MainAPI() {
    override var mainUrl = "https://anizone.to"
    override var name = "AniZone🦢"
    override val hasMainPage = true
    override var lang = "en"

    override val supportedTypes = setOf(
        TvType.Anime,
        TvType.AnimeMovie,
        TvType.OVA,
    )

    override val mainPage = mainPageOf(
        "/" to "Latest Anime",
        "/anime?sort=added-desc" to "Recently Added",
        "/anime?sort=release-desc" to "Latest Release",
        "/anime?type=4&sort=release-desc" to "Movies",
    )

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val url = when {
            request.data == "/" -> mainUrl
            page <= 1 -> "$mainUrl${request.data}"
            request.data.contains("?") -> "$mainUrl${request.data}&page=$page"
            else -> "$mainUrl${request.data}?page=$page"
        }
        val items = app.get(url, referer = "$mainUrl/").document.parseAnimeCards()
        return newHomePageResponse(request.name, items)
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val encoded = URLEncoder.encode(query, "UTF-8")
        return app.get("$mainUrl/anime?search=$encoded", referer = "$mainUrl/").document.parseAnimeCards()
    }

    override suspend fun load(url: String): LoadResponse {
        val document = app.get(url, referer = "$mainUrl/").document
        val title = document.selectFirst("h1")?.text()?.trim().orEmpty()
        val poster = document.selectFirst("img[src*=\"/images/anime/\"]")
            ?.getImageAttr()
            ?.let { fixUrlNull(it) }
        val type = document.detectType()
        val year = document.select("span")
            .eachText()
            .firstNotNullOfOrNull { YEAR_REGEX.find(it)?.value?.toIntOrNull() }
        val status = document.detectStatus()
        val tags = document.select("a[href^=\"$mainUrl/tag/\"], a[href^=\"/tag/\"]")
            .map { it.text().substringBefore("(").trim() }
            .filter { it.isNotBlank() && !it.equals("Tags", true) }
            .distinct()
        val plot = document.extractSynopsis()
        val episodes = document.parseEpisodes(url)
        val tracker = APIHolder.getTracker(listOf(title), TrackerType.getTypes(type), year, true)

        if (episodes.isEmpty() || type == TvType.AnimeMovie) {
            val movieData = episodes.firstOrNull()?.data ?: document.findWatchUrl(url) ?: "$url/1"
            return newMovieLoadResponse(title, url, type, movieData) {
                posterUrl = tracker?.image ?: poster
                backgroundPosterUrl = tracker?.cover
                this.year = year
                this.plot = plot
                this.tags = tags
                addMalId(tracker?.malId)
                addAniListId(tracker?.aniId?.toIntOrNull())
            }
        }

        return newAnimeLoadResponse(title, url, type) {
            posterUrl = tracker?.image ?: poster
            backgroundPosterUrl = tracker?.cover
            this.year = year
            this.plot = plot
            this.tags = tags
            showStatus = status
            addEpisodes(DubStatus.Subbed, episodes)
            addMalId(tracker?.malId)
            addAniListId(tracker?.aniId?.toIntOrNull())
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        var referer = data
        var document = app.get(data, referer = "$mainUrl/").document
        var source = document.selectFirst("media-player[src]")?.attr("src")?.trim()?.let { fixUrl(it) }
            ?: Regex("""https?://[^\s"'<>]+?\.m3u8[^\s"'<>]*""")
                .find(document.html())
                ?.value

        if (source == null) {
            val watchUrl = document.findWatchUrl(data) ?: return false
            referer = watchUrl
            document = app.get(watchUrl, referer = data).document
            source = document.selectFirst("media-player[src]")?.attr("src")?.trim()?.let { fixUrl(it) }
                ?: Regex("""https?://[^\s"'<>]+?\.m3u8[^\s"'<>]*""")
                    .find(document.html())
                    ?.value
                ?: return false
        }

        document.select("track[src]").forEach { track ->
            val subUrl = fixUrl(track.attr("src"))
            val label = track.attr("label").ifBlank {
                track.attr("srclang").ifBlank { "Subtitle" }
            }
            subtitleCallback(newSubtitleFile(label, subUrl))
        }

        callback(
            newExtractorLink(
                source = name,
                name = name,
                url = source,
                type = ExtractorLinkType.M3U8,
            ) {
                referer = referer
                quality = Qualities.Unknown.value
                headers = mapOf(
                    "Referer" to referer,
                    "User-Agent" to USER_AGENT,
                )
            }
        )

        return true
    }

    private fun Document.parseAnimeCards(): List<SearchResponse> {
        return select("a[href]")
            .asSequence()
            .filter {
                val href = it.absUrl("href").ifBlank { it.attr("href") }
                ANIME_DETAIL_REGEX.matches(href)
            }
            .distinctBy { it.absUrl("href").ifBlank { it.attr("href") } }
            .mapNotNull { it.toSearchResult() }
            .toList()
    }

    private fun Element.toSearchResult(): SearchResponse? {
        val href = fixUrlNull(absUrl("href").ifBlank { attr("href") }) ?: return null
        val card = parents().firstOrNull {
            it.selectFirst("img") != null || it.selectFirst("h3") != null
        } ?: this
        val title = attr("title")
            .ifBlank { selectFirst("[title]")?.attr("title").orEmpty() }
            .ifBlank { selectFirst("img[alt]")?.attr("alt").orEmpty() }
            .ifBlank { ownText() }
            .ifBlank { text() }
            .cleanTitle()
        if (title.isBlank() || title.equals("Anime", true)) return null

        val poster = card.selectFirst("img")?.getImageAttr()?.let { fixUrlNull(it) }
        val type = card.text().detectType()

        return newAnimeSearchResponse(title, href, type) {
            posterUrl = poster
        }
    }

    private fun Document.parseEpisodes(animeUrl: String): List<Episode> {
        val base = animeUrl.trimEnd('/')
        val episodeLinks = select("a[wire\\:key^=e-][href]").ifEmpty {
            select("a[href]")
        }

        return episodeLinks
            .mapNotNull { link ->
                if (link.text().contains("Start Watching", true)) return@mapNotNull null
                val href = fixUrlNull(link.absUrl("href").ifBlank { link.attr("href") }) ?: return@mapNotNull null
                if (!href.startsWith("$base/")) return@mapNotNull null
                val number = href.substringAfterLast("/").toIntOrNull() ?: return@mapNotNull null
                newEpisode(href) {
                    name = link.extractEpisodeTitle(number)
                    episode = number
                    posterUrl = link.selectFirst("img")?.getImageAttr()?.let { fixUrlNull(it) }
                }
            }
            .distinctBy { it.data }
            .sortedBy { it.episode ?: Int.MAX_VALUE }
    }

    private fun Element.extractEpisodeTitle(number: Int): String {
        val candidates = listOfNotNull(
            selectFirst("h3")?.text(),
            selectFirst("img[alt]")?.attr("alt")?.substringAfter(" - "),
            select(".grow.line-clamp-1, .grow .line-clamp-1, div.grow").lastOrNull()?.text(),
        )

        return candidates
            .map { it.cleanEpisodeTitle(number) }
            .firstOrNull { it.isNotBlank() && !it.isDurationText() }
            ?: "Episode $number"
    }

    private fun Document.findWatchUrl(animeUrl: String): String? {
        val base = animeUrl.trimEnd('/')
        return select("a[href]")
            .mapNotNull { link -> fixUrlNull(link.absUrl("href").ifBlank { link.attr("href") }) }
            .firstOrNull { href ->
                href.startsWith("$base/") && href.substringAfterLast("/").toIntOrNull() != null
            }
    }

    private fun Document.detectType(): TvType {
        val text = select("span").eachText().joinToString(" ")
        return text.detectType()
    }

    private fun String.detectType(): TvType {
        return when {
            contains("Movie", true) -> TvType.AnimeMovie
            contains("OVA", true) || contains("Special", true) -> TvType.OVA
            else -> TvType.Anime
        }
    }

    private fun Document.detectStatus(): ShowStatus {
        val text = select("span").eachText().joinToString(" ")
        return when {
            text.contains("Ongoing", true) -> ShowStatus.Ongoing
            text.contains("Completed", true) -> ShowStatus.Completed
            else -> ShowStatus.Completed
        }
    }

    private fun Document.extractSynopsis(): String? {
        val synopsisHeader = selectFirst("h2:contains(Synopsis), h3:contains(Synopsis)")
        val synopsis = synopsisHeader?.parent()?.select("p")?.eachText()?.joinToString("\n")
            ?: synopsisHeader?.nextElementSiblings()?.select("p")?.eachText()?.joinToString("\n")
        return synopsis?.trim()?.takeIf { it.isNotBlank() && !it.contains("disable your adblock", true) }
    }

    private fun Element.getImageAttr(): String {
        return when {
            hasAttr("data-src") -> attr("abs:data-src")
            hasAttr("data-lazy-src") -> attr("abs:data-lazy-src")
            hasAttr("srcset") -> attr("abs:srcset").substringBefore(" ")
            else -> attr("abs:src")
        }
    }

    private fun String.cleanTitle(): String {
        return replace(Regex("\\s+"), " ")
            .replace(Regex("\\s+-\\s+AniZone$", RegexOption.IGNORE_CASE), "")
            .trim()
    }

    private fun String.cleanEpisodeTitle(number: Int): String {
        var cleaned = cleanTitle()
        cleaned = when {
            " - Episode $number : " in cleaned -> cleaned.substringAfter(" - Episode $number : ")
            "Episode $number : " in cleaned -> cleaned.substringAfter("Episode $number : ")
            "Episode $number - " in cleaned -> cleaned.substringAfter("Episode $number - ")
            else -> cleaned
        }
        cleaned = cleaned
            .replace(Regex("^Episode\\s+$number\\s*:?\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("^$number\\s+"), "")
            .trim()
        return cleaned.ifBlank { "Episode $number" }
    }

    private fun String.isDurationText(): Boolean {
        return matches(Regex("""\d{1,2}:\d{2}(?::\d{2})?"""))
    }

    companion object {
        private val ANIME_DETAIL_REGEX = Regex("""https?://anizone\.to/anime/[A-Za-z0-9]+/?$""")
        private val YEAR_REGEX = Regex("""\b(?:19|20)\d{2}\b""")
    }
}

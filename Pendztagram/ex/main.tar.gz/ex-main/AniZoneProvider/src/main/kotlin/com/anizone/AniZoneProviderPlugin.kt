package com.anizone

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class AniZoneProviderPlugin : Plugin() {
    override fun load(context: Context) {
        registerMainAPI(AniZoneProvider())
    }
}

version = 1

cloudstream {
    description = "AniZone"
    language = "en"
    authors = listOf("Duro92")
    status = 1
    tvTypes = listOf(
        "Anime",
        "AnimeMovie",
        "OVA",
    )

    iconUrl = "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://anizone.to&size=%size%"
}

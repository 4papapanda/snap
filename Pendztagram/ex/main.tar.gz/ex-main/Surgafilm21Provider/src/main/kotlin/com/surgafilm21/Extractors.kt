package com.surgafilm21

import com.fasterxml.jackson.annotation.JsonProperty
import com.lagradost.cloudstream3.USER_AGENT
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.base64Decode
import com.lagradost.cloudstream3.base64DecodeArray
import com.lagradost.cloudstream3.network.WebViewResolver
import com.lagradost.cloudstream3.utils.AppUtils.tryParseJson
import com.lagradost.cloudstream3.utils.ExtractorApi
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.M3u8Helper
import com.lagradost.cloudstream3.utils.M3u8Helper.Companion.generateM3u8
import com.lagradost.cloudstream3.utils.Qualities
import com.lagradost.cloudstream3.utils.getAndUnpack
import com.lagradost.cloudstream3.utils.getPacked
import com.lagradost.cloudstream3.utils.newExtractorLink
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URI
import java.nio.charset.StandardCharsets
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

class SurgafilmByseJikuar : SurgafilmByseBase() {
    override var name = "Byse"
    override var mainUrl = "https://bysejikuar.com"
}

open class SurgafilmByseBase : ExtractorApi() {
    override var name = "Byse"
    override var mainUrl = "https://byse.sx"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (com.lagradost.cloudstream3.SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit,
    ) {
        val refererUrl = getBaseUrl(url)
        val playbackRoot = getPlayback(url, referer) ?: return
        val streamUrl = decryptPlayback(playbackRoot.playback) ?: return

        val links = M3u8Helper.generateM3u8(
            name,
            streamUrl,
            mainUrl,
            headers = mapOf("Referer" to refererUrl),
        )

        if (links.isNotEmpty()) {
            links.forEach(callback)
        } else {
            callback(
                newExtractorLink(name, name, streamUrl, ExtractorLinkType.M3U8) {
                    this.referer = refererUrl
                    this.quality = Qualities.Unknown.value
                },
            )
        }
    }

    private suspend fun getPlayback(pageUrl: String, referer: String?): SurgafilmPlaybackRoot? {
        val embedBase = getBaseUrl(pageUrl)
        val code = getVideoCode(pageUrl) ?: return null
        val headers = getEmbedHeaders(pageUrl, referer)
        val captchaToken = runCatching {
            app.get("$embedBase/api/videos/$code/embed/settings", headers = headers)
                .parsedSafe<SurgafilmByseSettings>()
                ?.takeIf { it.captchaRequired }
                ?.let { getCaptchaToken(embedBase, code, pageUrl, referer) }
        }.getOrNull()
        val body = """{"fingerprint":{"token":"","viewer_id":"$code","device_id":"$code","confidence":0.1}}"""
        return app.post(
            "$embedBase/api/videos/$code/embed/playback",
            headers = if (captchaToken.isNullOrBlank()) headers else headers + ("X-Captcha-Token" to captchaToken),
            requestBody = body.toRequestBody("application/json".toMediaTypeOrNull()),
        ).parsedSafe<SurgafilmPlaybackRoot>()
    }

    private suspend fun getCaptchaToken(embedBase: String, code: String, pageUrl: String, referer: String?): String? {
        val headers = getEmbedHeaders(pageUrl, referer)
        val body = """{"fingerprint":{"token":"","viewer_id":"$code","device_id":"$code","confidence":0.1}}"""
        val challenge = app.post(
            "$embedBase/api/videos/$code/embed/captcha",
            headers = headers,
            requestBody = body.toRequestBody("application/json".toMediaTypeOrNull()),
        ).parsedSafe<SurgafilmBysePowChallenge>() ?: return null
        val solution = solvePow(challenge.nonce, challenge.difficulty) ?: return null
        val verifyBody = """{"pow_token":"${challenge.token}","solution":"$solution"}"""
        return app.post(
            "$embedBase/api/videos/$code/embed/captcha/verify",
            headers = headers,
            requestBody = verifyBody.toRequestBody("application/json".toMediaTypeOrNull()),
        ).parsedSafe<SurgafilmBysePowVerify>()?.takeIf { it.status == "ok" }?.token
    }

    private fun getEmbedHeaders(pageUrl: String, referer: String?): Map<String, String> {
        val parentHost = referer?.let { runCatching { URI(it).host }.getOrNull() } ?: getBaseUrl(pageUrl)
        val parentReferer = referer ?: pageUrl
        return mapOf(
            "accept" to "*/*",
            "content-type" to "application/json",
            "referer" to pageUrl,
            "X-Embed-Origin" to parentHost,
            "X-Embed-Referer" to parentReferer,
            "X-Embed-Parent" to pageUrl,
        )
    }

    private fun getVideoCode(url: String): String? {
        val parts = URI(url).path.trim('/').split('/').filter { it.isNotBlank() }
        return when {
            parts.firstOrNull().equals("e", true) && parts.size >= 2 -> parts[1]
            parts.firstOrNull().equals("d", true) && parts.size >= 2 -> parts[1]
            parts.firstOrNull().equals("download", true) && parts.size >= 2 -> parts[1]
            parts.firstOrNull().equals("dwn", true) && parts.size >= 2 -> parts[1]
            parts.size >= 2 && parts[0].length in 3..5 -> parts[1]
            parts.isNotEmpty() -> parts.last()
            else -> null
        }
    }

    private fun decryptPlayback(playback: SurgafilmPlayback): String? {
        val parts = playback.version?.toIntOrNull()
            ?.let { listOf(it, 31 - it) }
            ?.mapNotNull { playback.keyParts.getOrNull(it - 1) }
            ?.takeIf { it.size == 2 }
            ?: playback.keyParts.take(2)
        val keyBytes = b64UrlDecode(parts[0]) + b64UrlDecode(parts[1])
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(keyBytes, "AES"),
            GCMParameterSpec(128, b64UrlDecode(playback.iv)),
        )
        val json = String(cipher.doFinal(b64UrlDecode(playback.payload)), StandardCharsets.UTF_8).removePrefix("\uFEFF")
        return tryParseJson<SurgafilmPlaybackDecrypt>(json)?.sources?.firstOrNull()?.url
    }

    private fun b64UrlDecode(value: String): ByteArray {
        val fixed = value.replace('-', '+').replace('_', '/')
        return base64DecodeArray(fixed + "=".repeat((4 - fixed.length % 4) % 4))
    }

    private fun getBaseUrl(url: String): String = URI(url).let { "${it.scheme}://${it.host}" }

    private fun solvePow(nonce: String, difficulty: Int, timeoutMs: Long = 20_000): String? {
        if (difficulty <= 0) return "0"
        val started = System.currentTimeMillis()
        val prefix = "$nonce:"
        var counter = 0
        while (System.currentTimeMillis() - started <= timeoutMs) {
            repeat(1024) {
                if (leadingZeroBits(powHash("$prefix$counter")) >= difficulty) return counter.toString()
                counter++
            }
        }
        return null
    }

    private fun powHash(value: String): IntArray {
        val state = intArrayOf(1779033703, -1150833019, 1013904242, -1521486534)
        value.forEach { char ->
            state[0] += char.code and 0xff
            state[0] = Integer.rotateLeft(state[0], 7)
            powMix(state)
        }
        repeat(8) { powMix(state) }
        val scratch = IntArray(512)
        repeat(scratch.size) { index ->
            powMix(state)
            scratch[index] = state[0] xor state[2]
        }
        repeat(2) {
            for (index in scratch.indices) {
                val target = scratch[index] and 511
                var current = scratch[index] + scratch[target]
                current = Integer.rotateLeft(current, 13)
                current = current xor (scratch[(index + 1) and 511] * -1640531535)
                scratch[index] = current
                state[0] = state[0] xor current
                powMix(state)
            }
        }
        return IntArray(8) { index ->
            powMix(state)
            var current = state[0]
            val start = index * 64
            for (offset in 0 until 64) {
                val item = scratch[start + offset]
                current += item
                current = Integer.rotateLeft(current, 5)
                current = current xor (item * -2048144777)
            }
            current xor state[2]
        }
    }

    private fun powMix(state: IntArray) {
        state[0] += state[1]
        state[3] = Integer.rotateLeft(state[3] xor state[0], 16)
        state[2] += state[3]
        state[1] = Integer.rotateLeft(state[1] xor state[2], 12)
        state[0] += state[1]
        state[3] = Integer.rotateLeft(state[3] xor state[0], 8)
        state[2] += state[3]
        state[1] = Integer.rotateLeft(state[1] xor state[2], 7)
    }

    private fun leadingZeroBits(values: IntArray): Int {
        var bits = 0
        for (value in values) {
            if (value == 0) {
                bits += 32
            } else {
                return bits + Integer.numberOfLeadingZeros(value)
            }
        }
        return bits
    }
}

data class SurgafilmByseSettings(
    @param:JsonProperty("captcha_required")
    val captchaRequired: Boolean = false,
)

data class SurgafilmBysePowChallenge(
    @param:JsonProperty("pow_nonce")
    val nonce: String,
    @param:JsonProperty("pow_difficulty")
    val difficulty: Int,
    @param:JsonProperty("pow_token")
    val token: String,
)

data class SurgafilmBysePowVerify(
    val status: String? = null,
    val token: String? = null,
)

data class SurgafilmPlaybackRoot(val playback: SurgafilmPlayback)

data class SurgafilmPlayback(
    val iv: String,
    val payload: String,
    val version: String? = null,
    @param:JsonProperty("key_parts")
    val keyParts: List<String>,
)

data class SurgafilmPlaybackDecrypt(val sources: List<SurgafilmPlaybackSource>? = null)

data class SurgafilmPlaybackSource(val url: String)

class SurgafilmMinochinos : SurgafilmEarnvids() {
    override var name = "Earnvids"
    override var mainUrl = "https://minochinos.com"
}

open class SurgafilmEarnvids : ExtractorApi() {
    override val name = "Earnvids"
    override val mainUrl = "https://dingtezuni.com"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (com.lagradost.cloudstream3.SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit,
    ) {
        val response = app.get(getEmbedUrl(url), referer = referer)
        val script = if (!getPacked(response.text).isNullOrEmpty()) {
            getAndUnpack(response.text).substringAfter("var links", getAndUnpack(response.text))
        } else {
            response.document.selectFirst("script:containsData(sources:)")?.data()
        } ?: return

        Regex(""":\s*"(.*?m3u8.*?)"""").findAll(script).forEach { match ->
            generateM3u8(
                name,
                match.groupValues[1],
                referer = "$mainUrl/",
                headers = mapOf("Origin" to mainUrl, "User-Agent" to USER_AGENT),
            ).forEach(callback)
        }
    }

    private fun getEmbedUrl(url: String): String {
        return when {
            url.contains("/d/") -> url.replace("/d/", "/v/")
            url.contains("/download/") -> url.replace("/download/", "/v/")
            url.contains("/file/") -> url.replace("/file/", "/v/")
            url.contains("/f/") -> url.replace("/f/", "/v/")
            else -> url
        }
    }
}

class SurgafilmTurbovidhls : ExtractorApi() {
    override var name = "Turbovidhls"
    override var mainUrl = "https://turbovidhls.com"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (com.lagradost.cloudstream3.SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit,
    ) {
        val page = app.get(
            url,
            headers = mapOf("User-Agent" to USER_AGENT),
            referer = referer ?: "$mainUrl/",
        )
        val embedReferer = page.url
        val headers = mapOf(
            "Referer" to embedReferer,
            "Origin" to mainUrl,
            "User-Agent" to USER_AGENT,
            "Accept" to "*/*",
        )

        var masterUrl = page.document.selectFirst("#video_player[data-hash]")
            ?.attr("data-hash")
            ?.trim()
            .orEmpty()

        if (masterUrl.isBlank()) {
            val playerScript = page.document.select("script").joinToString("\n") { it.data() }
            masterUrl = Regex("""var\s+urlPlay\s*=\s*['"]([^'"]+)['"]""")
                .find(playerScript)
                ?.groupValues
                ?.getOrNull(1)
                .orEmpty()
                .trim()
        }

        if (masterUrl.isBlank()) return
        masterUrl = when {
            masterUrl.startsWith("//") -> "https:$masterUrl"
            masterUrl.startsWith("/") -> "$mainUrl$masterUrl"
            else -> masterUrl
        }

        val generated = generateM3u8(
            source = name,
            name = name,
            streamUrl = masterUrl,
            referer = embedReferer,
            headers = headers,
        ).distinctBy { it.url }

        if (generated.isNotEmpty()) {
            generated.forEach(callback)
        } else {
            callback(
                newExtractorLink(name, name, masterUrl, ExtractorLinkType.M3U8) {
                    this.referer = embedReferer
                    this.headers = headers
                    this.quality = Qualities.Unknown.value
                },
            )
        }
    }
}

class SurgafilmAbyssplayer : ExtractorApi() {
    override val name = "AbyssPlayer"
    override val mainUrl = "https://abyssplayer.com"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (com.lagradost.cloudstream3.SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit,
    ) {
        val videoId = URI(url).rawQuery
            ?.split("&")
            ?.firstOrNull { it.substringBefore("=") == "v" }
            ?.substringAfter("=")
            ?.takeIf { it.isNotBlank() }
            ?: URI(url).path.trim('/').takeIf { it.isNotBlank() }
            ?: return

        val emitted = mutableSetOf<String>()
        runCatching {
            val page = app.get("$mainUrl/$videoId", headers = mapOf("User-Agent" to USER_AGENT), referer = referer).document
            val encrypted = Regex("""const\s+datas\s*=\s*"([^"]*)"""")
                .find(page.select("script").joinToString("\n") { it.data() })
                ?.groupValues
                ?.getOrNull(1)
                ?: return@runCatching
            val json = JSONObject(
                app.post(
                    "https://enc-dec.app/api/dec-abyss",
                    headers = mapOf("User-Agent" to USER_AGENT, "Origin" to "https://playhydrax.com"),
                    requestBody = """{"text":"$encrypted"}""".toRequestBody("application/json".toMediaTypeOrNull()),
                ).text,
            )
            val sources = json.optJSONObject("result")?.optJSONArray("sources") ?: return@runCatching
            for (i in 0 until sources.length()) {
                val source = sources.optJSONObject(i) ?: continue
                val sourceUrl = source.optString("url").takeIf { it.isNotBlank() } ?: continue
                emitSource(sourceUrl, url, qualityFromText(source.toString()), emitted, callback)
            }
        }

        if (emitted.isNotEmpty()) return

        val playerData = listOf("https://abysscdn.com", "https://player-cdn.com").firstNotNullOfOrNull { base ->
            runCatching {
                val response = app.get("$base/?v=$videoId", headers = mapOf("User-Agent" to USER_AGENT), referer = referer)
                Regex("""PLAYER\s*\(\s*atob\s*\(\s*["']([^"']+)["']""")
                    .find(response.text)
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.let { base to it }
            }.getOrNull()
        } ?: return

        val payload = tryParseJson<SurgafilmAbyssPayload>(base64Decode(playerData.second)) ?: return
        val domain = payload.domain?.trim()?.trim('/') ?: return
        val fileId = payload.id?.trim() ?: return
        val sources = payload.sources.orEmpty().ifEmpty { listOf("sd", "hd", "fullhd") }
        sources.forEach { source ->
            val prefix = when (source.lowercase()) {
                "sd", "mhd", "360p", "480p" -> ""
                "hd", "720p" -> "www"
                "fullhd", "1080p" -> "whw"
                "qhd", "1440p" -> "uhd"
                "uhd", "4k", "2160p" -> "k4"
                else -> return@forEach
            }
            emitSource("https://$domain/$prefix$fileId", playerData.first, qualityFromText(source), emitted, callback)
        }
    }

    private suspend fun emitSource(
        sourceUrl: String,
        refererUrl: String,
        quality: Int,
        emitted: MutableSet<String>,
        callback: (ExtractorLink) -> Unit,
    ) {
        if (!emitted.add(sourceUrl)) return
        callback(
            newExtractorLink(
                name,
                if (quality > 0) "$name ${quality}p" else name,
                sourceUrl,
                if (sourceUrl.contains(".m3u8", true)) ExtractorLinkType.M3U8 else ExtractorLinkType.VIDEO,
            ) {
                this.referer = refererUrl
                if (quality > 0) this.quality = quality
                this.headers = mapOf("Referer" to refererUrl, "User-Agent" to USER_AGENT)
            },
        )
    }

    private fun qualityFromText(text: String): Int {
        return Regex("""(?<!\d)(2160|1440|1080|720|480|360)(?:p)?(?!\d)""", RegexOption.IGNORE_CASE)
            .find(text)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
            ?: 0
    }
}

data class SurgafilmAbyssPayload(
    val domain: String? = null,
    val id: String? = null,
    val sources: List<String>? = null,
)

class SurgafilmVidlink : ExtractorApi() {
    override val name = "Vidlink"
    override val mainUrl = "https://vidlink.pro"
    override val requiresReferer = true

    override suspend fun getUrl(
        url: String,
        referer: String?,
        subtitleCallback: (com.lagradost.cloudstream3.SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit,
    ) {
        val uri = URI(url)
        val parts = uri.path.trim('/').split('/').filter { it.isNotBlank() }
        val type = parts.getOrNull(0)?.lowercase() ?: return
        if (type != "movie" && type != "tv") return

        val watchUrl = when (type) {
            "movie" -> "$mainUrl/movie/${parts.getOrNull(1) ?: return}"
            else -> "$mainUrl/tv/${parts.getOrNull(1) ?: return}/${parts.getOrNull(2) ?: return}/${parts.getOrNull(3) ?: return}"
        }

        val playlist = app.get(
            watchUrl,
            headers = mapOf("User-Agent" to USER_AGENT),
            referer = referer ?: "$mainUrl/",
            interceptor = WebViewResolver(
                Regex("""https://vidlink\.pro/api/b/(?:movie/[^?&\s"'<>]+(?:\?multiLang=(?:true|false))?|tv/[^/\s"'<>]+/\d+/\d+/(?:true|false))"""),
                timeout = 15_000L,
            ),
        ).parsedSafe<SurgafilmVidlinkSources>()?.stream?.playlist ?: return

        val generated = generateM3u8(
            source = name,
            name = name,
            streamUrl = playlist,
            referer = "$mainUrl/",
            headers = mapOf("Referer" to "$mainUrl/", "User-Agent" to USER_AGENT),
        ).distinctBy { it.url }

        if (generated.isNotEmpty()) {
            generated.forEach(callback)
        } else {
            callback(
                newExtractorLink(name, name, playlist, ExtractorLinkType.M3U8) {
                    this.referer = "$mainUrl/"
                    this.headers = mapOf("Referer" to "$mainUrl/", "User-Agent" to USER_AGENT)
                    this.quality = Qualities.Unknown.value
                },
            )
        }
    }
}

data class SurgafilmVidlinkSources(
    val stream: SurgafilmVidlinkStream? = null,
)

data class SurgafilmVidlinkStream(
    val playlist: String? = null,
)

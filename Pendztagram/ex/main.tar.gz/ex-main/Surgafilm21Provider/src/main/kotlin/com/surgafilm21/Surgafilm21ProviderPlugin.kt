package com.surgafilm21

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class Surgafilm21ProviderPlugin : Plugin() {
    override fun load(context: Context) {
        registerMainAPI(Surgafilm21Provider())
        registerExtractorAPI(SurgafilmByseJikuar())
        registerExtractorAPI(SurgafilmMinochinos())
        registerExtractorAPI(SurgafilmAbyssplayer())
        registerExtractorAPI(SurgafilmTurbovidhls())
        registerExtractorAPI(SurgafilmVidlink())
    }
}

package com.surgafilm21

import com.lagradost.cloudstream3.Episode
import com.lagradost.cloudstream3.ErrorLoadingException
import com.lagradost.cloudstream3.HomePageResponse
import com.lagradost.cloudstream3.LoadResponse
import com.lagradost.cloudstream3.LoadResponse.Companion.addActors
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.MainPageRequest
import com.lagradost.cloudstream3.Score
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.USER_AGENT
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.mainPageOf
import com.lagradost.cloudstream3.newEpisode
import com.lagradost.cloudstream3.newHomePageResponse
import com.lagradost.cloudstream3.newMovieLoadResponse
import com.lagradost.cloudstream3.newMovieSearchResponse
import com.lagradost.cloudstream3.newTvSeriesLoadResponse
import com.lagradost.cloudstream3.newTvSeriesSearchResponse
import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.httpsify
import com.lagradost.cloudstream3.utils.loadExtractor
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URI
import java.net.URLEncoder

class Surgafilm21Provider : MainAPI() {
    override var mainUrl = "https://surgafilm21.website"
    override var name = "Surgafilm21🐦"
    override var lang = "id"
    override val hasMainPage = true
    override val hasDownloadSupport = true
    override val supportedTypes = setOf(TvType.Movie, TvType.TvSeries, TvType.AsianDrama)

    override val mainPage = mainPageOf(
        "/populer/page/%d/" to "Populer",
        "/latest/page/%d/" to "Latest",
        "/series/ongoing/page/%d/" to "Ongoing Series",
        "/series/page/%d/" to "Daftar Series",
        "/genre/romance/page/%d/" to "Romance",
        "/genre/comedy/page/%d/" to "Comedy",
        "/genre/drama/page/%d/" to "Drama",
        "/genre/action/page/%d/" to "Action",
        "/genre/animation/page/%d/" to "Animation",
        "/genre/science-fiction/page/%d/" to "Science Fiction",
        "/genre/horror/page/%d/" to "Horror",
        "/genre/mystery/page/%d/" to "Mystery",
        "/genre/war/page/%d/" to "War",
        "/country/thailand/page/%d/" to "Thailand",
        "/country/china/page/%d/" to "China",
    )

    private val headers = mapOf(
        "User-Agent" to USER_AGENT,
        "Accept" to "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    )

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val document = app.get(pageUrl(request.data, page), headers = headers, referer = "$mainUrl/").document
        val items = document.toSearchResults()
        val hasNext = document.hasNextPage(page)
        return newHomePageResponse(request.name, items, hasNext = hasNext)
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        return app.get("$mainUrl/?s=$encoded", headers = headers, referer = "$mainUrl/").document.toSearchResults()
    }

    override suspend fun load(url: String): LoadResponse {
        val fixedUrl = normalizeUrl(url, mainUrl) ?: url
        val response = app.get(fixedUrl, headers = headers, referer = "$mainUrl/")
        val document = response.document
        val resolvedUrl = response.url

        val title = document.selectFirst("main meta[itemprop=name], meta[property=og:title], h1")
            ?.let { it.attr("content").ifBlank { it.text() } }
            ?.cleanTitle()
            ?.takeIf { it.isNotBlank() }
            ?: throw ErrorLoadingException("Title not found")

        val poster = document.selectFirst("main meta[itemprop=image], meta[property=og:image], img[itemprop=image], img")
            ?.imageUrl()
            ?.fixImageQuality()
        val plot = document.extractPlot()
        val year = document.selectFirst("main meta[itemprop=datePublished], [itemprop=datePublished]")
            ?.let { it.attr("content").ifBlank { it.text() } }
            ?.extractYear()
            ?: title.extractYear()
        val duration = document.selectFirst("main meta[itemprop=duration]")
            ?.attr("content")
            ?.extractInt()
        val rating = document.selectFirst("[itemprop=ratingValue], meta[itemprop=ratingValue]")
            ?.let { it.attr("content").ifBlank { it.text() } }
            ?.toScore()
            ?: document.selectFirst("meta[property=og:description]")
                ?.attr("content")
                ?.substringAfter("Rating:", "")
                ?.toScore()
        val tags = document.select("a[itemprop=genre], a[href*='/genre/']")
            .map { it.text().trim() }
            .filter { it.isNotBlank() }
            .distinct()
        val actors = document.select("[itemprop=actor] [itemprop=name], [itemprop=actor] img[alt]")
            .map { it.attr("content").ifBlank { it.attr("alt").ifBlank { it.text() } }.trim() }
            .filter { it.isNotBlank() && !it.equals("Image", true) }
            .distinct()
        val recommendations = document.select("a[href]")
            .mapNotNull { it.toSearchResultFromAnchor() }
            .filterNot { it.url == resolvedUrl || it.url == fixedUrl }
            .distinctBy { it.url }

        val episodes = document.extractEpisodes()
        val isSeries = resolvedUrl.contains("/series/", true) ||
            fixedUrl.contains("/series/", true) ||
            episodes.isNotEmpty() ||
            document.selectFirst("meta[itemprop=numberOfEpisodes]") != null

        return if (isSeries) {
            newTvSeriesLoadResponse(title, resolvedUrl, TvType.TvSeries, episodes.ifEmpty { listOf(newEpisode(resolvedUrl)) }) {
                posterUrl = poster
                backgroundPosterUrl = poster
                this.year = year
                plot?.let { this.plot = it }
                this.tags = tags
                addActors(actors)
                duration?.let { this.duration = it }
                rating?.let { score = Score.from10(it) }
                this.recommendations = recommendations
            }
        } else {
            newMovieLoadResponse(title, resolvedUrl, TvType.Movie, resolvedUrl) {
                posterUrl = poster
                backgroundPosterUrl = poster
                this.year = year
                plot?.let { this.plot = it }
                this.tags = tags
                addActors(actors)
                duration?.let { this.duration = it }
                rating?.let { score = Score.from10(it) }
                this.recommendations = recommendations
            }
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val fixedUrl = normalizeUrl(data, mainUrl) ?: data
        val document = app.get(fixedUrl, headers = headers, referer = "$mainUrl/").document
        var handled = false

        val playerUrls = linkedSetOf<String>()
        document.select("button.server-btn[onclick*=player-proxy], button[onclick*=player-proxy]")
            .mapNotNullTo(playerUrls) { button ->
                Regex("""switchServer(?:Direct)?\('([^']+)""")
                    .find(button.attr("onclick"))
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.let { normalizeUrl(Jsoup.parse(it).text(), fixedUrl) }
            }
        document.select("iframe[src], iframe[data-src], iframe[data-fallback]")
            .flatMap { listOf(it.attr("data-src"), it.attr("data-fallback"), it.attr("src")) }
            .mapNotNullTo(playerUrls) { normalizeUrl(httpsify(it), fixedUrl) }

        for (playerUrl in playerUrls) {
            val candidates = resolvePlayerCandidates(playerUrl, fixedUrl)
            for (candidate in candidates.ifEmpty { listOf(playerUrl) }) {
                if (candidate.contains("ads.", true) || candidate.contains("otieu.com", true)) continue
                handled = true
                runCatching { loadExtractor(candidate, playerUrl, subtitleCallback, callback) }
            }
        }

        document.select("a[href*='dl.sf21.space'], a[href*='/get/'][href]")
            .mapNotNull { normalizeUrl(it.attr("href"), fixedUrl) }
            .forEach { downloadUrl ->
                handled = true
                runCatching { loadExtractor(downloadUrl, fixedUrl, subtitleCallback, callback) }
            }

        return handled
    }

    private suspend fun resolvePlayerCandidates(playerUrl: String, referer: String): List<String> {
        val page = runCatching {
            app.get(playerUrl, headers = headers, referer = referer).document
        }.getOrNull() ?: return emptyList()

        return page.select("iframe[src], iframe[data-src], iframe[data-fallback]")
            .flatMap { iframe -> listOf(iframe.attr("data-src"), iframe.attr("data-fallback"), iframe.attr("src")) }
            .mapNotNull { normalizeUrl(httpsify(Jsoup.parse(it).text().ifBlank { it }), playerUrl) }
            .filterNot { it == "about:blank" || it.contains("ads.", true) || it.contains("otieu.com", true) }
            .distinct()
    }

    private fun Document.toSearchResults(): List<SearchResponse> {
        val gridResults = select(
            "#infinite-container > div[itemscope], " +
                "main > div.grid > div[itemscope], " +
                "main div.grid > div[itemscope]"
        )
            .mapNotNull { it.toSearchResultFromCard() }
            .distinctBy { it.url }

        if (gridResults.isNotEmpty()) return gridResults

        val cardResults = select("div[itemscope][itemtype*=Movie], div[itemscope][itemtype*=TVSeries]")
            .mapNotNull { it.toSearchResultFromCard() }
            .distinctBy { it.url }

        if (cardResults.isNotEmpty()) return cardResults

        return select("a[href]")
            .asSequence()
            .filter { anchor ->
                val href = normalizeUrl(anchor.attr("href"), mainUrl).orEmpty()
                href.isTitlePageUrl()
            }
            .mapNotNull { it.toSearchResultFromAnchor() }
            .distinctBy { it.url }
            .toList()
    }

    private fun Element.toSearchResultFromCard(): SearchResponse? {
        val anchor = selectFirst("a[itemprop=url][href], a[href]") ?: return null
        val href = normalizeUrl(anchor.attr("href"), mainUrl) ?: return null
        if (!href.isTitlePageUrl()) return null

        val title = listOf(
            selectFirst("[itemprop=name]")?.attr("content"),
            selectFirst("[itemprop=name]")?.text(),
            anchor.attr("title"),
            selectFirst("img[alt]")?.attr("alt"),
            selectFirst("img[title]")?.attr("title"),
            anchor.text(),
        ).firstOrNull { !it.isNullOrBlank() }?.cleanTitle() ?: return null

        val poster = selectFirst("img[itemprop=image], a[href] img, img")?.imageUrl()?.fixImageQuality()
        val rating = visibleRating()
        val quality = text().let {
            Regex("""\b(?:HD|WEB-DL|BLURAY|CAM|TS|4K)\b""", RegexOption.IGNORE_CASE).find(it)?.value
        }
        val isSeries = href.contains("/series/", true) ||
            attr("itemtype").contains("TVSeries", true) ||
            select("meta[itemprop=numberOfEpisodes]").isNotEmpty() ||
            text().contains("SERIES", true)

        return if (isSeries) {
            newTvSeriesSearchResponse(title, href, TvType.TvSeries) {
                posterUrl = poster
                rating?.let { score = Score.from10(it) }
            }
        } else {
            newMovieSearchResponse(title, href, TvType.Movie) {
                posterUrl = poster
                quality?.let { addQuality(it) }
                rating?.let { score = Score.from10(it) }
            }
        }
    }

    private fun Element.toSearchResultFromAnchor(): SearchResponse? {
        val href = normalizeUrl(attr("href"), mainUrl) ?: return null
        if (!href.isTitlePageUrl()) return null

        val container = parents().firstOrNull {
            it.selectFirst("img, h2, h3, h4, p, [itemprop=name]") != null
        } ?: this
        val title = listOf(
            attr("title"),
            selectFirst("[itemprop=name], h1, h2, h3, h4, p")?.text(),
            selectFirst("img[alt]")?.attr("alt"),
            container.selectFirst("[itemprop=name], h1, h2, h3, h4, p")?.text(),
            container.selectFirst("img[alt]")?.attr("alt"),
            text(),
        ).firstOrNull { !it.isNullOrBlank() }?.cleanTitle() ?: return null

        val poster = (selectFirst("img") ?: container.selectFirst("img"))?.imageUrl()?.fixImageQuality()
        val rating = container.visibleRating()
        val quality = container.text().substringAfter("•", "").let {
            Regex("""\b(?:HD|WEB-DL|BLURAY|CAM|TS|4K)\b""", RegexOption.IGNORE_CASE).find(it)?.value
        }
        val isSeries = href.contains("/series/", true) ||
            container.text().contains("SERIES", true) ||
            container.text().contains("Season", true) ||
            container.text().contains("Episode", true)

        return if (isSeries) {
            newTvSeriesSearchResponse(title, href, TvType.TvSeries) {
                posterUrl = poster
                rating?.let { score = Score.from10(it) }
            }
        } else {
            newMovieSearchResponse(title, href, TvType.Movie) {
                posterUrl = poster
                quality?.let { addQuality(it) }
                rating?.let { score = Score.from10(it) }
            }
        }
    }

    private fun Element.visibleRating(): Double? {
        return select(".rating, .gmr-rating-item, [class*=rating], [class*=imdb], [class*=score]")
            .asSequence()
            .filterNot { it.tagName().equals("meta", true) }
            .mapNotNull { element ->
                val text = element.ownText().ifBlank { element.text() }
                text.toScore()
            }
            .firstOrNull { it > 0.0 && it <= 10.0 && it != 7.5 }
    }

    private fun Document.extractEpisodes(): List<Episode> {
        val anchors = select("#tab-episodes [itemprop=episode] a[href], [itemprop=episode] a[href]")
            .ifEmpty { select("a[href*='/series/episode/']") }

        return anchors
            .mapNotNull { anchor ->
                val href = normalizeUrl(anchor.attr("href"), mainUrl) ?: return@mapNotNull null
                val episodeContainer = anchor.parents().firstOrNull {
                    it.hasAttr("itemprop") && it.attr("itemprop").equals("episode", true)
                }
                val label = listOf(
                    episodeContainer?.selectFirst("[itemprop=name]")?.text(),
                    anchor.selectFirst("[itemprop=name]")?.text(),
                    anchor.text(),
                )
                    .firstOrNull { !it.isNullOrBlank() }
                    ?.replace(Regex("""\s+"""), " ")
                    ?.trim()
                    ?.takeUnless { it.equals("Play Now", true) }
                    ?: href.toEpisodeName()
                val number = episodeContainer?.selectFirst("meta[itemprop=episodeNumber]")?.attr("content")?.toIntOrNull()
                    ?: Regex("""episode-(\d+)""", RegexOption.IGNORE_CASE).find(href)?.groupValues?.getOrNull(1)?.toIntOrNull()
                    ?: Regex("""(?:EP|Episode)\s*(\d+)""", RegexOption.IGNORE_CASE).find(label)?.groupValues?.getOrNull(1)?.toIntOrNull()
                val season = Regex("""season-(\d+)""", RegexOption.IGNORE_CASE).find(href)?.groupValues?.getOrNull(1)?.toIntOrNull()
                    ?: Regex("""Season\s*(\d+)""", RegexOption.IGNORE_CASE).find(label)?.groupValues?.getOrNull(1)?.toIntOrNull()
                    ?: 1
                newEpisode(href) {
                    name = label.ifBlank { number?.let { "Episode $it" } }
                    episode = number
                    this.season = season
                }
            }
            .distinctBy { it.data }
            .sortedWith(compareBy<Episode> { it.season ?: 0 }.thenBy { it.episode ?: Int.MAX_VALUE })
    }

    private fun Document.extractPlot(): String? {
        val visibleDescription = select(
            "article [itemprop=description]:not(meta), " +
                "main [itemprop=description]:not(meta), " +
                "[itemprop=description]:not(meta), " +
                "#synopsis"
        )
            .map { it.text().cleanPlot() }
            .firstOrNull { !it.isNullOrBlank() && !it.endsWith("...") }

        if (!visibleDescription.isNullOrBlank()) return visibleDescription

        return selectFirst("meta[property=og:description], meta[name=description]")
            ?.attr("content")
            ?.cleanPlot()
    }

    private fun Document.hasNextPage(page: Int): Boolean {
        val nextPage = page + 1
        val hasNextLink = select("a[href], link[href]").any { element ->
            val href = normalizeUrl(element.attr("href"), mainUrl).orEmpty()
            val path = runCatching { URI(href).path.trimEnd('/') }.getOrNull().orEmpty()
            val text = element.text()
            path.endsWith("/page/$nextPage", true) ||
                element.attr("rel").equals("next", true) ||
                text.contains("NEXT", true)
        }

        if (hasNextLink) return true

        val pageInfo = Regex("""(?i)\bPage\s+(\d+)\s+of\s+(\d+)""")
            .find(text())
            ?: return false
        val current = pageInfo.groupValues.getOrNull(1)?.toIntOrNull() ?: return false
        val total = pageInfo.groupValues.getOrNull(2)?.toIntOrNull() ?: return false
        return current < total
    }

    private fun pageUrl(pattern: String, page: Int): String {
        val path = if (page <= 1) {
            pattern.replace("/page/%d/", "/").replace("page/%d/", "")
        } else {
            pattern.format(page)
        }
        return normalizeUrl(path, mainUrl) ?: "$mainUrl/"
    }

    private fun normalizeUrl(raw: String, baseUrl: String): String? {
        val clean = Jsoup.parse(raw).text()
            .trim()
            .replace("&amp;", "&")
            .takeIf {
                it.isNotBlank() &&
                    !it.startsWith("javascript:", true) &&
                    !it.startsWith("data:", true)
            } ?: return null

        return when {
            clean == "about:blank" -> clean
            clean.startsWith("//") -> "https:$clean"
            clean.startsWith("http://", true) || clean.startsWith("https://", true) -> clean
            else -> runCatching { URI(baseUrl).resolve(clean).toString() }.getOrNull()
        }
    }

    private fun Element.imageUrl(): String? {
        return listOf(
            attr("abs:content"),
            attr("abs:data-src"),
            attr("abs:data-lazy-src"),
            attr("abs:srcset").substringBefore(" "),
            attr("abs:src"),
            attr("content"),
            attr("data-src"),
            attr("data-lazy-src"),
            attr("srcset").substringBefore(" "),
            attr("src"),
        ).firstOrNull { it.isNotBlank() }?.let { normalizeUrl(it, mainUrl) }
    }

    private fun String.isTitlePageUrl(): Boolean {
        val uri = runCatching { URI(this) }.getOrNull() ?: return false
        if (!uri.host.isSurgafilmHost()) return false
        val path = uri.path.trim('/')
        if (path.isBlank()) return false
        if (path.startsWith("genre/") || path.startsWith("country/") || path.startsWith("year/")) return false
        if (path.startsWith("series/episode/")) return true
        if (path.startsWith("series/") && path.substringAfter("series/").contains(Regex("""\d{4}$"""))) return true
        return path.count { it == '/' } == 0 && path.contains(Regex("""-\d{4}$"""))
    }

    private fun String?.isSurgafilmHost(): Boolean {
        val host = this.orEmpty().lowercase()
        return host == "surgafilm21.website" || host == "surgafilm21.homes"
    }

    private fun String.cleanTitle(): String {
        return Jsoup.parse(this).text()
            .replace(Regex("""(?i)^Nonton\s+(?:Film|Series)\s+"""), "")
            .replace(Regex("""(?i)\s+Sub\s+Indo.*$"""), "")
            .replace(Regex("""(?i)\s*-\s*SURGAFILM21.*$"""), "")
            .replace(Regex("""(?i)\b(?:WATCH NOW|FAVORITE|Favorite Movie|Favorite Series|Play Now)\b"""), "")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun String.toEpisodeName(): String {
        return substringAfterLast('/')
            .replace('-', ' ')
            .replace(Regex("""\bseason\s+(\d+)\s+episode\s+(\d+)\b""", RegexOption.IGNORE_CASE), "Season $1 Episode $2")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    }

    private fun String.cleanPlot(): String? {
        return replace(Regex("""(?i)^Streaming\s+(?:film|series)\s+.*?Rating:\s*.*?\d+(?:\.\d+)?\.\s*"""), "")
            .replace(Regex("""\s+"""), " ")
            .trim()
            .ifBlank { null }
    }

    private fun String.fixImageQuality(): String {
        return replace("/w185/", "/w500/").replace("/w300/", "/w500/")
    }

    private fun String.extractYear(): Int? {
        return Regex("""(19|20)\d{2}""").find(this)?.value?.toIntOrNull()
    }

    private fun String.extractInt(): Int? {
        return Regex("""\d+""").find(this)?.value?.toIntOrNull()
    }

    private fun String.toScore(): Double? {
        return Regex("""\d+(?:\.\d+)?""").find(this)?.value?.toDoubleOrNull()
    }
}

version = 7

cloudstream {
    description = "Surgafilm21"
    language = "id"
    authors = listOf("ExtCloud")

    status = 1
    tvTypes = listOf(
        "Movie",
        "TvSeries",
        "AsianDrama",
    )

    iconUrl =
        "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://surgafilm21.website&size=%size%"
}

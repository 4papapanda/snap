version = 2

cloudstream {
    description = "PMSM (Pencuri Movie Sub Malay)"
    language = "id"
    authors = listOf("Duro92")
    status = 1
    tvTypes = listOf(
        "Movie",
        "TvSeries",
    )

    iconUrl = "https://t2.gstatic.com/faviconV2?client=SOCIAL&type=FAVICON&fallback_opts=TYPE,SIZE,URL&url=https://ww105.pencurimoviesubmalay.guru&size=%size%"
    isCrossPlatform = false
}

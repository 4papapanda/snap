package com.hexated

import android.annotation.SuppressLint
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import com.lagradost.cloudstream3.Actor
import com.lagradost.cloudstream3.Episode
import com.lagradost.cloudstream3.ErrorLoadingException
import com.lagradost.cloudstream3.HomePageResponse
import com.lagradost.cloudstream3.LoadResponse
import com.lagradost.cloudstream3.LoadResponse.Companion.addActors
import com.lagradost.cloudstream3.LoadResponse.Companion.addImdbId
import com.lagradost.cloudstream3.LoadResponse.Companion.addTMDbId
import com.lagradost.cloudstream3.LoadResponse.Companion.addTrailer
import com.lagradost.cloudstream3.MainAPI
import com.lagradost.cloudstream3.MainPageRequest
import com.lagradost.cloudstream3.Score
import com.lagradost.cloudstream3.SearchQuality
import com.lagradost.cloudstream3.SearchResponse
import com.lagradost.cloudstream3.SearchResponseList
import com.lagradost.cloudstream3.SubtitleFile
import com.lagradost.cloudstream3.TvType
import com.lagradost.cloudstream3.addDate
import com.lagradost.cloudstream3.app
import com.lagradost.cloudstream3.base64Decode
import com.lagradost.cloudstream3.getQualityFromString
import com.lagradost.cloudstream3.mainPageOf
import com.lagradost.cloudstream3.newEpisode
import com.lagradost.cloudstream3.newHomePageResponse
import com.lagradost.cloudstream3.newMovieLoadResponse
import com.lagradost.cloudstream3.newMovieSearchResponse
import com.lagradost.cloudstream3.newSubtitleFile
import com.lagradost.cloudstream3.newTvSeriesLoadResponse
import com.lagradost.cloudstream3.newTvSeriesSearchResponse
import com.lagradost.cloudstream3.network.CloudflareKiller
import com.lagradost.cloudstream3.toNewSearchResponseList
import com.lagradost.api.Log
import com.lagradost.cloudstream3.utils.AppUtils
import com.lagradost.cloudstream3.utils.AppUtils.toJson
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.newExtractorLink
import com.lagradost.nicehttp.NiceResponse
import kotlinx.coroutines.delay
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Response
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.text.Normalizer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class IdlixProvider : MainAPI() {
    override var mainUrl = base64Decode("aHR0cHM6Ly96Mi5pZGxpeGt1LmNvbQ==")
    override var name = "Idlix🐍"
    override val hasMainPage = true
    override var lang = "id"
    override val hasDownloadSupport = true
    override val supportedTypes = setOf(
        TvType.Movie,
        TvType.TvSeries,
        TvType.Anime,
        TvType.AsianDrama
    )

    companion object {
        var context: android.content.Context? = null
    }

    private val cloudflareInterceptor by lazy { CloudflareKiller() }
    private val turnstileInterceptor by lazy { IdlixTurnstileInterceptor() }

    override val mainPage = mainPageOf(
        "$mainUrl/api/movies?page=%d&limit=36&sort=createdAt" to "Movie Terbaru",
        "$mainUrl/api/series?page=%d&limit=36&sort=createdAt" to "TV Series Terbaru",
        "$mainUrl/api/browse?page=%d&limit=36&sort=latest&network=prime-video" to "Amazon Prime",
        "$mainUrl/api/browse?page=%d&limit=36&sort=latest&network=apple-tv-plus" to "Apple TV+",
        "$mainUrl/api/browse?page=%d&limit=36&sort=latest&network=disney-plus" to "Disney+",
        "$mainUrl/api/browse?page=%d&limit=36&sort=latest&network=hbo" to "HBO",
        "$mainUrl/api/browse?page=%d&limit=36&sort=latest&network=netflix" to "Netflix",
    )

    override suspend fun getMainPage(
        page: Int,
        request: MainPageRequest
    ): HomePageResponse {
        val url = if (request.data.contains("%d")) request.data.format(page) else request.data
        val res = idlixGet(url, timeout = 10000L).parsedSafe<ApiResponse>() ?: return newHomePageResponse(request.name, emptyList())
        val home = res.data.map { item ->
            val title = item.title ?: "UnKnown"
            val poster = item.posterPath?.let { "https://image.tmdb.org/t/p/w342$it" }
            if (item.contentType == "movie") {
                val movieurl = "$mainUrl/api/movies/${item.slug}"
                newMovieSearchResponse(title, movieurl, TvType.Movie) {
                    this.posterUrl = poster
                    this.year = item.releaseDate?.substringBefore("-")?.toIntOrNull()
                    this.quality = getSearchQuality(item.quality)
                    this.score = Score.from10(item.voteAverage)
                }
            } else {
                val seriesurl = "$mainUrl/api/series/${item.slug}"
                newTvSeriesSearchResponse(title, seriesurl, TvType.TvSeries) {
                    this.posterUrl = poster
                    this.year = item.releaseDate?.substringBefore("-")?.toIntOrNull()
                    this.score = Score.from10(item.voteAverage)
                    this.quality = getSearchQuality(item.quality)
                }
            }
        }

        return newHomePageResponse(request.name, home)
    }

    override suspend fun quickSearch(query: String): List<SearchResponse>? = search(query,1)?.items

    override suspend fun search(query: String, page: Int): SearchResponseList? {
        val url = "$mainUrl/api/search?q=$query&page=$page&limit=8"
        val res = idlixGet(url).parsedSafe<SearchApiResponse>() ?: return null
        val items = res.results
        val results = items.mapNotNull { item ->
            val title = item.title
            val poster = item.posterPath.let { "https://image.tmdb.org/t/p/w342$it" }
            val year = (item.releaseDate ?: item.firstAirDate)?.substringBefore("-")?.toIntOrNull()

            val link = when (item.contentType) {
                "movie" -> "$mainUrl/api/movies/${item.slug}"
                "tv_series", "series" -> "$mainUrl/api/series/${item.slug}"
                else -> return@mapNotNull null
            }

            val rating = item.voteAverage

            if (item.contentType == "movie") {
                newMovieSearchResponse(title, link, TvType.Movie) {
                    this.posterUrl = poster
                    this.year = year
                    this.quality = getQualityFromString(item.quality)
                    this.score = rating.let { Score.from10(it) }
                }
            } else {
                newTvSeriesSearchResponse(title, link, TvType.TvSeries) {
                    this.posterUrl = poster
                    this.year = year
                    this.score = rating.let { Score.from10(it) }
                }
            }
        }

        return results.toNewSearchResponseList()
    }

    override suspend fun load(url: String): LoadResponse {
        val response = idlixGet(url, timeout = 10000L)

        val data = response.parsedSafe<DetailResponse>()
            ?: throw ErrorLoadingException("Invalid JSON")

        val title = data.title ?: "Unknown"
        val poster = data.posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
        val backdrop = data.backdropPath?.let { "https://image.tmdb.org/t/p/w780$it" }

        val year = (data.releaseDate ?: data.firstAirDate)
            ?.substringBefore("-")
            ?.toIntOrNull()

        val tags = data.genres?.mapNotNull { it.name } ?: emptyList()
        val logourl = "https://image.tmdb.org/t/p/w500"+data.logoPath
        val actors = data.cast?.map {
            Actor(it.name ?: "", it.profilePath?.let { p -> "https://image.tmdb.org/t/p/w185$p" })
        } ?: emptyList()

        val trailer = data.trailerUrl
        val rating = data.voteAverage

        val relatedUrl = if (data.seasons != null) {
            "$mainUrl/api/series/${data.slug}/related"
        } else {
            "$mainUrl/api/movies/${data.slug}/related"
        }

        val recommendations = try {
            idlixGet(relatedUrl, referer = mainUrl)
                .parsedSafe<ApiResponse>()?.data?.mapNotNull { item ->

                    val title = item.title ?: return@mapNotNull null
                    val poster = item.posterPath?.let { "https://image.tmdb.org/t/p/w342$it" }

                    val link = if (item.contentType == "movie") {
                        "$mainUrl/api/movies/${item.slug}"
                    } else {
                        "$mainUrl/api/series/${item.slug}"
                    }

                    if (item.contentType == "movie") {
                        newMovieSearchResponse(title, link, TvType.Movie) {
                            this.posterUrl = poster
                            this.year = (item.releaseDate ?: item.firstAirDate)
                                ?.substringBefore("-")
                                ?.toIntOrNull()
                        }
                    } else {
                        newTvSeriesSearchResponse(title, link, TvType.TvSeries) {
                            this.posterUrl = poster
                            this.year = (item.releaseDate ?: item.firstAirDate)
                                ?.substringBefore("-")
                                ?.toIntOrNull()
                        }
                    }

                } ?: emptyList()

        } catch (_: Exception) {
            emptyList()
        }

        return if (data.seasons != null) {
            val episodes = mutableListOf<Episode>()

            data.firstSeason?.episodes?.forEach { ep ->
                episodes.add(
                    newEpisode( LoadData(
                        id = ep.id ?: return@forEach,
                        type = "episode"
                    ).toJson()) {
                        this.name = ep.name
                        this.season = data.firstSeason.seasonNumber
                        this.episode = ep.episodeNumber
                        this.description = ep.overview
                        this.runTime = ep.runtime
                        this.score = Score.from10(ep.voteAverage?.toString())
                        addDate(ep.airDate)
                        this.posterUrl = ep.stillPath?.let { "https://image.tmdb.org/t/p/w300$it" }
                    }
                )
            }

            data.seasons.forEach { season ->
                val seasonNum = season.seasonNumber ?: return@forEach
                if (seasonNum == data.firstSeason?.seasonNumber) return@forEach
                val seasonUrl = "$mainUrl/api/series/${data.slug}/season/$seasonNum"

                val seasonData = try {
                    val res = idlixGet(seasonUrl, referer = mainUrl)
                    res.parsedSafe<SeasonWrapper>()?.season
                } catch (_: Exception) {
                    null
                }

                seasonData?.episodes?.forEach { ep ->
                    episodes.add(
                        newEpisode( LoadData(
                            id = ep.id ?: return@forEach,
                            type = "episode"
                        ).toJson()) {
                            this.name = ep.name
                            this.season = seasonNum
                            this.episode = ep.episodeNumber
                            this.description = ep.overview
                            this.runTime = ep.runtime
                            this.score = Score.from10(ep.voteAverage?.toString())
                            addDate(ep.airDate)
                            this.posterUrl = ep.stillPath?.let { "https://image.tmdb.org/t/p/w300$it" }
                        }
                    )
                }
            }

            newTvSeriesLoadResponse(title, url, TvType.TvSeries, episodes) {
                this.posterUrl = poster
                this.backgroundPosterUrl = backdrop
                this.logoUrl = logourl
                this.year = year
                this.plot = data.overview
                this.tags = tags
                this.score = Score.from10(rating?.toString())
                addActors(actors)
                addTrailer(trailer)
                addTMDbId(data.tmdbId)
                addImdbId(data.imdbId)
                this.recommendations = recommendations
            }
        } else {
            newMovieLoadResponse(title, url, TvType.Movie,  LoadData(
                id = data.id ?: "",
                type = "movie"
            ).toJson()) {
                this.posterUrl = poster
                this.backgroundPosterUrl = backdrop
                this.logoUrl = logourl
                this.year = year
                this.plot = data.overview
                this.tags = tags
                this.score = Score.from10(rating?.toString())
                addActors(actors)
                addTrailer(trailer)
                addTMDbId(data.tmdbId)
                addImdbId(data.imdbId)
                this.recommendations = recommendations
            }
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {

        val parsed = try {
            AppUtils.parseJson<LoadData>(data)
        } catch (_: Exception) {
            null
        } ?: return false

        val contentId = parsed.id
        val contentType = parsed.type

        val playResponse = idlixGet(
            "$mainUrl/api/watch/play-info/$contentType/$contentId",
            headers = apiHeaders()
        )

        val cookies = playResponse.cookies
        val playInfo = playResponse.parsedSafe<Res>() ?: return false

        val waitTime = (playInfo.unlockAt - playInfo.serverNow).coerceAtLeast(0)
        val totalWait = waitTime / 1000
        var elapsed = 0L
        while (elapsed < totalWait) {
            Log.d(name, "Waiting: ${elapsed}s / ${totalWait}s")
            delay(1000)
            elapsed++
        }

        val claimApi = idlixPost(
            "$mainUrl/api/watch/session/claim",
            headers = apiHeaders(),
            cookies = cookies,
            requestBody = """{"gateToken":"${playInfo.gateToken}"}"""
                .toRequestBody("application/json".toMediaType())
        ).parsedSafe<RedeemRes>() ?: return false

        val redeemUrl = claimApi.redeemUrl.takeIf { it.isNotBlank() } ?: return false

        val iframeResponse = app.post(
            redeemUrl,
            headers = redeemHeaders(),
            requestBody = """{"claim":"${claimApi.claim}"}"""
                .toRequestBody("text/plain".toMediaType()),
        ).parsedSafe<Iframe>() ?: return false

        var emitted = false
        iframeResponse.url?.takeIf { it.isNotBlank() }?.let { streamUrl ->
            emitted = true
            callback(
                newExtractorLink(name, name, streamUrl, ExtractorLinkType.M3U8) {
                    this.referer = mainUrl
                }
            )
            }

        iframeResponse.subtitles.forEach { subtitle ->
            val path = subtitle.path.takeIf { it.isNotBlank() } ?: return@forEach
            subtitleCallback(
                newSubtitleFile(
                    subtitle.label.takeIf { it.isNotBlank() } ?: subtitle.lang,
                    path
                )
            )
        }

        return emitted
    }

    private fun apiHeaders() = mapOf(
        "Referer" to "$mainUrl/",
        "Origin" to mainUrl,
        "Accept" to "*/*",
        "Content-Type" to "application/json"
    )

    private fun redeemHeaders() = mapOf(
        "Content-Type" to "text/plain"
    )

    private suspend fun idlixGet(
        url: String,
        headers: Map<String, String> = emptyMap(),
        referer: String? = null,
        timeout: Long = 30L
    ): NiceResponse {
        val first = app.get(
            url,
            headers = headers,
            referer = referer,
            timeout = timeout,
            interceptor = cloudflareInterceptor
        )
        if (isUsableResponse(first)) return first
        return app.get(
            url,
            headers = headers,
            referer = referer,
            timeout = timeout,
            interceptor = turnstileInterceptor
        )
    }

    private suspend fun idlixPost(
        url: String,
        headers: Map<String, String> = emptyMap(),
        cookies: Map<String, String> = emptyMap(),
        requestBody: RequestBody,
        timeout: Long = 30L
    ): NiceResponse {
        val first = app.post(
            url,
            headers = headers,
            cookies = cookies,
            requestBody = requestBody,
            timeout = timeout,
            interceptor = cloudflareInterceptor
        )
        if (isUsableResponse(first)) return first
        return app.post(
            url,
            headers = headers,
            cookies = cookies,
            requestBody = requestBody,
            timeout = timeout,
            interceptor = turnstileInterceptor
        )
    }

    private fun isUsableResponse(response: NiceResponse): Boolean {
        if (response.code == 403 || response.code == 429 || response.code == 503) return false
        return !looksLikeCloudflareChallenge(response.text)
    }

    private fun looksLikeCloudflareChallenge(html: String?): Boolean {
        val preview = html?.take(128 * 1024).orEmpty()
        if (preview.isBlank()) return false
        val hints = listOf(
            "cf-challenge",
            "cf-browser-verification",
            "cf_clearance",
            "challenge-platform",
            "Performing security verification",
            "Verifying you are human",
            "Just a moment",
            "Attention Required",
            "/cdn-cgi/challenge-platform/"
        )
        return hints.any { preview.contains(it, ignoreCase = true) }
    }
}

class IdlixTurnstileInterceptor(
    private val targetCookies: List<String> = listOf("cf_clearance", "__cf_bm")
) : Interceptor {
    companion object {
        private const val POLL_INTERVAL_MS = 500L
        private const val MAX_ATTEMPTS = 60
        private const val PAGE_WAIT_SECONDS = 45L
    }

    private fun getCookieHeader(url: String, domainUrl: String): String {
        val manager = CookieManager.getInstance()
        return manager.getCookie(url) ?: manager.getCookie(domainUrl) ?: ""
    }

    private fun getCookieValue(url: String, domainUrl: String): String? {
        val raw = getCookieHeader(url, domainUrl)
        if (raw.isBlank()) return null
        return raw.split(";")
            .map { it.trim() }
            .firstNotNullOfOrNull { cookie ->
                targetCookies.firstOrNull { target -> cookie.startsWith("$target=") }
                    ?.let { cookie.substringAfter("=") }
                    ?.takeIf { it.isNotBlank() }
            }
    }

    private fun invalidateCookie(domainUrl: String) {
        CookieManager.getInstance().apply {
            targetCookies.forEach { cookie ->
                setCookie(domainUrl, "$cookie=; Max-Age=0")
            }
            flush()
        }
    }

    private fun hasChallenge(response: Response): Boolean {
        if (response.code == 403 || response.code == 429 || response.code == 503) return true

        val contentType = response.header("Content-Type").orEmpty()
        if (!contentType.contains("text/html", ignoreCase = true)) return false

        val preview = runCatching { response.peekBody(128 * 1024).string() }.getOrDefault("")
        if (preview.isBlank()) return false

        val challengeHints = listOf(
            "cf-challenge",
            "cf-browser-verification",
            "cf_clearance",
            "challenge-platform",
            "Performing security verification",
            "Verifying you are human",
            "Just a moment",
            "Attention Required",
            "/cdn-cgi/challenge-platform/"
        )
        return challengeHints.any { preview.contains(it, ignoreCase = true) }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun intercept(chain: Interceptor.Chain): Response {
        val originalRequest = chain.request()
        val url = originalRequest.url.toString()
        val domainUrl = "${originalRequest.url.scheme}://${originalRequest.url.host}"
        val cookieManager = CookieManager.getInstance()

        if (getCookieValue(url, domainUrl) != null) {
            val response = chain.proceed(
                originalRequest.newBuilder()
                    .header("Cookie", getCookieHeader(url, domainUrl))
                    .build()
            )
            if (!hasChallenge(response)) return response
            response.close()
            invalidateCookie(domainUrl)
        }

        val context = IdlixProvider.context ?: return chain.proceed(originalRequest)
        val handler = Handler(Looper.getMainLooper())
        var webView: WebView? = null
        var resolvedUserAgent = originalRequest.header("User-Agent") ?: ""
        val challengeLatch = CountDownLatch(1)

        handler.post {
            try {
                val wv = WebView(context).also { webView = it }
                CookieManager.getInstance().setAcceptCookie(true)
                CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
                wv.settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    databaseEnabled = true
                    javaScriptCanOpenWindowsAutomatically = true
                    loadsImagesAutomatically = true
                    if (resolvedUserAgent.isNotBlank()) userAgentString = resolvedUserAgent
                    resolvedUserAgent = userAgentString
                }
                wv.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView, finishedUrl: String) {
                        super.onPageFinished(view, finishedUrl)
                        cookieManager.flush()
                        if (getCookieValue(finishedUrl, domainUrl) != null) {
                            challengeLatch.countDown()
                        }
                    }
                }
                wv.loadUrl(url)
            } catch (e: Exception) {
                challengeLatch.countDown()
                e.printStackTrace()
            }
        }

        challengeLatch.await(PAGE_WAIT_SECONDS, TimeUnit.SECONDS)

        var attempts = 0
        while (attempts < MAX_ATTEMPTS && getCookieValue(url, domainUrl) == null) {
            Thread.sleep(POLL_INTERVAL_MS)
            cookieManager.flush()
            attempts++
        }

        handler.post {
            try {
                webView?.apply {
                    stopLoading()
                    clearCache(false)
                    destroy()
                }
                webView = null
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        val finalResponse = chain.proceed(
            originalRequest.newBuilder()
                .header("Cookie", getCookieHeader(url, domainUrl))
                .apply { if (resolvedUserAgent.isNotBlank()) header("User-Agent", resolvedUserAgent) }
                .build()
        )

        if (!hasChallenge(finalResponse)) return finalResponse
        return finalResponse
    }
}

fun getSearchQuality(check: String?): SearchQuality? {
    val s = check ?: return null
    val u = Normalizer.normalize(s, Normalizer.Form.NFKC).lowercase()
    val patterns = listOf(
        Regex("\\b(4k|ds4k|uhd|2160p)\\b", RegexOption.IGNORE_CASE) to SearchQuality.FourK,

        // CAM / THEATRE SOURCES FIRST
        Regex("\\b(hdts|hdcam|hdtc)\\b", RegexOption.IGNORE_CASE) to SearchQuality.HdCam,
        Regex("\\b(camrip|cam[- ]?rip)\\b", RegexOption.IGNORE_CASE) to SearchQuality.CamRip,
        Regex("\\b(cam)\\b", RegexOption.IGNORE_CASE) to SearchQuality.Cam,

        // WEB / RIP
        Regex("\\b(web[- ]?dl|webrip|webdl)\\b", RegexOption.IGNORE_CASE) to SearchQuality.WebRip,

        // BLURAY
        Regex("\\b(bluray|bdrip|blu[- ]?ray)\\b", RegexOption.IGNORE_CASE) to SearchQuality.BlueRay,

        // RESOLUTIONS
        Regex("\\b(1440p|qhd)\\b", RegexOption.IGNORE_CASE) to SearchQuality.BlueRay,
        Regex("\\b(1080p|fullhd)\\b", RegexOption.IGNORE_CASE) to SearchQuality.HD,
        Regex("\\b(720p)\\b", RegexOption.IGNORE_CASE) to SearchQuality.SD,

        // GENERIC HD LAST
        Regex("\\b(hdrip|hdtv)\\b", RegexOption.IGNORE_CASE) to SearchQuality.HD,

        Regex("\\b(dvd)\\b", RegexOption.IGNORE_CASE) to SearchQuality.DVD,
        Regex("\\b(hq)\\b", RegexOption.IGNORE_CASE) to SearchQuality.HQ,
        Regex("\\b(rip)\\b", RegexOption.IGNORE_CASE) to SearchQuality.CamRip
    )


    for ((regex, quality) in patterns) if (regex.containsMatchIn(u)) return quality
    return null
}


data class Res(
    val gateToken: String,
    val serverNow: Long,
    val unlockAt: Long,
)

data class RedeemRes(
    val kind: String,
    val claim: String,
    val redeemUrl: String,
    val videoId: String,
    val title: String,
    val durationSec: Long,
    val viewerTier: String,
    val maxHeight: Long,
)

data class Iframe(
    val code: String? = null,
    val url: String? = null,
    val expiresAt: Long? = null,
    val subtitles: List<Subtitle> = emptyList(),
    val videoId: String? = null,
)

data class Subtitle(
    val lang: String = "Unknown",
    val label: String = "",
    val path: String = "",
)


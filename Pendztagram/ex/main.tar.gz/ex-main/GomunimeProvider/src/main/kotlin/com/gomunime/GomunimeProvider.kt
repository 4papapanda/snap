package com.gomunime

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.utils.ExtractorLink
import com.lagradost.cloudstream3.utils.ExtractorLinkType
import com.lagradost.cloudstream3.utils.Qualities
import com.lagradost.cloudstream3.utils.loadExtractor
import com.lagradost.cloudstream3.utils.newExtractorLink
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import java.net.URI
import java.net.URLEncoder

class GomunimeProvider : MainAPI() {
    override var mainUrl = "https://gomunime.top"
    override var name = "Gomunime🦅"
    override var lang = "id"
    override val hasMainPage = true
    override val hasDownloadSupport = true

    override val supportedTypes = setOf(
        TvType.Anime,
        TvType.AnimeMovie,
        TvType.OVA,
    )

    override val mainPage = mainPageOf(
        "/status/ongoing" to "Anime Ongoing",
        "/status/completed" to "Anime Tamat",
        "/koleksi/anime-skor-mal-tertinggi" to "Top Rated",
        "/genre/action" to "Action",
    )

    override suspend fun getMainPage(page: Int, request: MainPageRequest): HomePageResponse {
        val document = app.get(pageUrl(request.data, page), referer = "$mainUrl/").document
        val items = document.selectHomeCards(request.data)
            .mapNotNull { it.toSearchResult() }
            .distinctBy { it.url }
        val hasNext = request.data != "/" &&
            document.select("a[rel=next], a[href*='?page=${page + 1}']").isNotEmpty()
        return newHomePageResponse(request.name, items, hasNext = hasNext)
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val encoded = URLEncoder.encode(query.trim(), "UTF-8")
        return app.get("$mainUrl/search?q=$encoded", referer = "$mainUrl/").document
            .select("a.card-netflix[href]")
            .mapNotNull { it.toSearchResult() }
            .distinctBy { it.url }
    }

    override suspend fun load(url: String): LoadResponse {
        val fixedUrl = normalizeUrl(url, mainUrl) ?: url
        val firstDocument = app.get(fixedUrl, referer = "$mainUrl/").document
        val seriesUrl = if (fixedUrl.isEpisodeUrl()) {
            firstDocument.select("nav a[href]")
                .mapNotNull { normalizeUrl(it.attr("href"), mainUrl) }
                .lastOrNull { it.startsWith(mainUrl) && !it.isEpisodeUrl() && it != "$mainUrl/" }
                ?: fixedUrl.substringBeforeLast("-episode-")
        } else {
            fixedUrl
        }
        val document = if (seriesUrl != fixedUrl) {
            app.get(seriesUrl, referer = fixedUrl).document
        } else {
            firstDocument
        }

        val title = document.selectFirst("h1, meta[property=og:title], title")
            ?.let { it.attr("content").ifBlank { it.text() } }
            ?.cleanTitle()
            ?.takeIf { it.isNotBlank() }
            ?: throw ErrorLoadingException("Title not found")

        val poster = document.selectFirst("meta[property=og:image], article img, img[alt='$title']")
            ?.imageUrl()
        val background = document.selectFirst("meta[name=twitter:image], meta[property=og:image]")
            ?.imageUrl()
            ?: poster
        val type = getType(document)
        val status = getStatus(document.text())
        val year = Regex("""\b(?:19|20)\d{2}\b""")
            .find(document.select(".badge-glass, a[href*='/tahun/'], script[type='application/ld+json']").text())
            ?.value
            ?.toIntOrNull()
        val score = document.selectFirst(".badge-rating")
            ?.text()
            ?.toScore()
            ?: Regex(""""ratingValue"\s*:\s*"?(\\d+(?:\\.\\d+)?)""")
                .find(document.html())
                ?.groupValues
                ?.getOrNull(1)
                ?.toDoubleOrNull()
        val tags = document.select("article a[href*='/genre/']")
            .map { it.text().trim() }
            .filter { it.isNotBlank() }
            .distinct()
        val plot = document.selectFirst("section:has(h2:contains(Sinopsis)) .prose, .prose")
            ?.cleanTextBlock()
        val episodeDocuments = listOf(document) + document.getEpisodePageUrls(seriesUrl)
            .mapNotNull { pageUrl ->
                runCatching { app.get(pageUrl, referer = seriesUrl).document }.getOrNull()
            }
        val episodes = episodeDocuments
            .flatMap { pageDocument ->
                pageDocument.select("#episode-list a[href]")
                    .mapNotNull { it.toEpisode() }
            }
            .distinctBy { it.data }
            .sortedBy { it.episode ?: Int.MAX_VALUE }
        val recommendations = document.select("section a.card-netflix[href]")
            .mapNotNull { it.toSearchResult() }
            .filterNot { it.url == seriesUrl }
            .distinctBy { it.url }

        return if (type == TvType.AnimeMovie || episodes.size <= 1) {
            val playUrl = episodes.firstOrNull()?.data
                ?: document.selectFirst("a.btn-primary[href*='-episode-']")?.attr("href")?.let { normalizeUrl(it, mainUrl) }
                ?: fixedUrl
            newMovieLoadResponse(title, seriesUrl, type, playUrl) {
                posterUrl = poster
                backgroundPosterUrl = background
                this.year = year
                this.plot = plot
                this.tags = tags
                this.recommendations = recommendations
                score?.let { this.score = Score.from10(it) }
            }
        } else {
            newAnimeLoadResponse(title, seriesUrl, type) {
                posterUrl = poster
                backgroundPosterUrl = background
                this.year = year
                this.plot = plot
                this.tags = tags
                this.showStatus = status
                this.recommendations = recommendations
                score?.let { this.score = Score.from10(it) }
                addEpisodes(DubStatus.Subbed, episodes)
            }
        }
    }

    override suspend fun loadLinks(
        data: String,
        isCasting: Boolean,
        subtitleCallback: (SubtitleFile) -> Unit,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val fixedUrl = normalizeUrl(data, mainUrl) ?: data
        val document = app.get(fixedUrl, referer = "$mainUrl/").document
        val emitted = linkedSetOf<String>()
        val iframes = document.select("iframe[src]")
            .mapNotNull { normalizeUrl(it.attr("src"), fixedUrl) }
            .distinct()

        suspend fun emit(mediaUrl: String, referer: String, label: String) {
            val cleanUrl = normalizeUrl(mediaUrl.decodeEscaped(), referer) ?: return
            if (!emitted.add(cleanUrl)) return
            callback(
                newExtractorLink(
                    source = name,
                    name = "$name $label",
                    url = cleanUrl,
                    type = when {
                        cleanUrl.contains(".m3u8", true) || cleanUrl.contains("play.php", true) -> ExtractorLinkType.M3U8
                        else -> ExtractorLinkType.VIDEO
                    },
                ) {
                    this.referer = referer
                    this.quality = qualityFromName(label)
                    this.headers = mapOf(
                        "Referer" to referer,
                        "User-Agent" to USER_AGENT,
                    )
                }
            )
        }

        iframes.forEachIndexed { index, iframe ->
            runCatching { loadExtractor(iframe, fixedUrl, subtitleCallback, callback) }
            val iframeResponse = runCatching {
                app.get(iframe, referer = fixedUrl, headers = mapOf("User-Agent" to USER_AGENT))
            }.getOrNull() ?: return@forEachIndexed
            val iframeDocument = iframeResponse.document
            val label = iframe.hostLabel().ifBlank { "Server ${index + 1}" }

            iframeDocument.select("source[src], video[src]")
                .mapNotNull { it.attr("src").takeIf(String::isNotBlank) }
                .forEach { emit(it, iframe, label) }

            Regex("""["']file["']\s*:\s*["']([^"']+)""", RegexOption.IGNORE_CASE)
                .findAll(iframeResponse.text)
                .map { it.groupValues[1] }
                .forEach { emit(it, iframe, label) }

            Regex("""https?://[^\s"'\\<>]+(?:\.m3u8|\.mp4|/videoplayback)[^\s"'\\<>]*""", RegexOption.IGNORE_CASE)
                .findAll(iframeResponse.text.decodeEscaped())
                .map { it.value }
                .forEach { emit(it, iframe, label) }
        }

        return emitted.isNotEmpty() || iframes.isNotEmpty()
    }

    private fun pageUrl(path: String, page: Int): String {
        val url = normalizeUrl(path, mainUrl) ?: mainUrl
        if (page <= 1) return url
        return if (url.contains("?")) "$url&page=$page" else "$url?page=$page"
    }

    private fun Document.selectHomeCards(path: String): List<Element> {
        return select("a.card-netflix[href]")
    }

    private fun Document.getEpisodePageUrls(seriesUrl: String): List<String> {
        val maxPage = select("#episode-list nav a[href*='page=']")
            .mapNotNull { link ->
                Regex("""[?&]page=(\d+)""")
                    .find(link.attr("href"))
                    ?.groupValues
                    ?.getOrNull(1)
                    ?.toIntOrNull()
            }
            .maxOrNull()
            ?: return emptyList()

        return (2..maxPage.coerceAtMost(MAX_EPISODE_PAGES)).map { page ->
            if (seriesUrl.contains("?")) "$seriesUrl&page=$page" else "$seriesUrl?page=$page"
        }
    }

    private fun Element.toSearchResult(): SearchResponse? {
        val href = normalizeUrl(attr("href"), mainUrl) ?: return null
        if (!href.startsWith(mainUrl) || href.contains("/genre/") || href.contains("/status/") || href.contains("/tahun/")) return null
        val title = listOf(
            selectFirst("h3")?.text(),
            selectFirst("img[alt]")?.attr("alt"),
            attr("title"),
            text(),
        ).firstOrNull { !it.isNullOrBlank() }?.cleanTitle() ?: return null
        if (title.length < 2 || title.equals("Tonton", true)) return null

        val poster = selectFirst("img")?.imageUrl()
        val type = getType(text(), href)
        val episode = Regex("""Episode\s*(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
            .find(text())
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()

        return newAnimeSearchResponse(title, href, type) {
            posterUrl = poster
            episode?.let { addSub(it) }
        }
    }

    private fun Element.toEpisode(): Episode? {
        val href = normalizeUrl(attr("href"), mainUrl) ?: return null
        if (!href.startsWith(mainUrl) || href.contains("?page=", true) || href.contains("#")) return null
        val label = listOf(
            selectFirst(".text-sm.font-bold")?.text(),
            selectFirst("div.text-sm")?.text(),
            selectFirst("h3")?.text(),
            text().replace(Regex("""\s+"""), " ").trim(),
        ).firstOrNull { !it.isNullOrBlank() }.orEmpty()
        if (!label.contains("Episode", true)) return null
        val number = Regex("""(?:Episode\s*)?(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
            .find(label)
            ?.groupValues
            ?.getOrNull(1)
            ?.toDoubleOrNull()
            ?: Regex("""-episode-(\d+(?:\.\d+)?)""", RegexOption.IGNORE_CASE)
                .find(href)
                ?.groupValues
                ?.getOrNull(1)
                ?.toDoubleOrNull()
        val date = selectFirst("div.text-xs")?.text()?.trim()

        return newEpisode(href) {
            name = label.ifBlank { number?.let { "Episode ${it.toInt()}" } }
            episode = number?.toInt()
            date?.let { description = it }
        }
    }

    private fun getType(document: Document): TvType {
        val text = document.select("article .badge-sub, article, meta[name=description], script[type='application/ld+json']")
            .text()
        return getType(text, document.location())
    }

    private fun getType(text: String, url: String): TvType {
        return when {
            text.contains("Movie", true) || url.contains("movie", true) -> TvType.AnimeMovie
            text.contains("OVA", true) || text.contains("ONA", true) || text.contains("Special", true) -> TvType.OVA
            else -> TvType.Anime
        }
    }

    private fun getStatus(text: String): ShowStatus? {
        return when {
            text.contains("Ongoing", true) -> ShowStatus.Ongoing
            text.contains("Completed", true) || text.contains("Tamat", true) -> ShowStatus.Completed
            else -> null
        }
    }

    private fun Element.imageUrl(): String? {
        return listOf(
            attr("abs:content"),
            attr("abs:data-src"),
            attr("abs:data-lazy-src"),
            attr("abs:srcset").substringBefore(" "),
            attr("abs:src"),
            attr("content"),
            attr("data-src"),
            attr("data-lazy-src"),
            attr("srcset").substringBefore(" "),
            attr("src"),
        ).firstOrNull { it.isNotBlank() }?.let { normalizeUrl(it, mainUrl) }
    }

    private fun Element.cleanTextBlock(): String? {
        val content = clone()
        content.select("script, style, iframe, a").remove()
        return content.text()
            .replace(Regex("""\s+"""), " ")
            .trim()
            .ifBlank { null }
    }

    private fun normalizeUrl(raw: String, baseUrl: String): String? {
        val clean = Jsoup.parse(raw).text()
            .trim()
            .replace("&amp;", "&")
            .takeIf { it.isNotBlank() && !it.startsWith("javascript:", true) && !it.startsWith("data:", true) }
            ?: return null
        return when {
            clean.startsWith("//") -> "https:$clean"
            clean.startsWith("http://", true) || clean.startsWith("https://", true) -> clean
            else -> runCatching { URI(baseUrl).resolve(clean).toString() }.getOrNull()
        }
    }

    private fun String.cleanTitle(): String {
        return Jsoup.parse(this).text()
            .replace(Regex("""(?i)^Nonton\s+Anime\s+"""), "")
            .replace(Regex("""(?i)\s+Sub\s*Indo.*$"""), "")
            .replace(Regex("""(?i)\s+\|\s*Gomunime.*$"""), "")
            .replace(Regex("""(?i)\s+Episode\s+\d+(?:\.\d+)?.*$"""), "")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun String.isEpisodeUrl(): Boolean {
        return contains(Regex("""-episode-\d+(?:\.\d+)?/?(?:$|[?#])""", RegexOption.IGNORE_CASE))
    }

    private fun String.toScore(): Double? {
        return Regex("""\d+(?:\.\d+)?""").find(this)?.value?.toDoubleOrNull()
    }

    private fun String.decodeEscaped(): String {
        return replace("\\/", "/")
            .replace("\\u002F", "/")
            .replace("\\u003D", "=", true)
            .replace("\\u0026", "&", true)
            .replace("&amp;", "&")
    }

    private fun String.hostLabel(): String {
        val host = runCatching { URI(this).host.orEmpty() }.getOrDefault("")
        return when {
            host.contains("anime-indo", true) -> "B-TUBE"
            host.contains("xtwap", true) -> "CEPAT"
            host.contains("gdplayer", true) -> "GDRIVE"
            else -> host.substringBefore(".").uppercase()
        }
    }

    private fun qualityFromName(value: String): Int {
        return Regex("""\b(2160|1440|1080|720|480|360|240)\b""")
            .find(value)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
            ?: Qualities.Unknown.value
    }

    companion object {
        private const val MAX_EPISODE_PAGES = 100
    }
}

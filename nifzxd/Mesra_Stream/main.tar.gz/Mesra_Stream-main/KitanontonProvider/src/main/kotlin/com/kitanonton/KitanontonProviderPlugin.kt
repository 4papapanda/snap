package com.kitanonton

import android.content.Context
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin
import com.lagradost.cloudstream3.plugins.Plugin

@CloudstreamPlugin
class KitanontonProviderPlugin : Plugin() {
    override fun load(context: Context) {
        registerMainAPI(KitanontonProvider())
    }
}

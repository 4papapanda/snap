version = 9

cloudstream {
    authors     = listOf("Anomali")
    language    = "id"
    description = "Best Japan AV porn site, free forever, high speed, no lag, over 100,000 videos, daily update, no ads while playing video."

    /**
     * Status int as the following:
     * 0: Down
     * 1: Ok
     * 2: Slow
     * 3: Beta only
    **/
    status  = 1 // will be 3 if unspecified
    tvTypes = listOf("NSFW")
    iconUrl = "https://podjav.tv/wp-content/uploads/2025/02/favicon-podjav.ico"
}

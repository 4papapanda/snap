package eu.kanade.tachiyomi.multisrc.raijinscans

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
class LatestUpdatesDto(
    val success: Boolean,
    val data: LatestUpdatesDataDto,
)

@Serializable
class LatestUpdatesDataDto(
    @SerialName("manga_html") val mangaHtml: String,
    @SerialName("current_page") val currentPage: Int,
    @SerialName("total_pages") val totalPages: Int,
)

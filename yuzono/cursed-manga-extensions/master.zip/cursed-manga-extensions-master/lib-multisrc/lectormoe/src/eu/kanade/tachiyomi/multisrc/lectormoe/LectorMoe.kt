package eu.kanade.tachiyomi.multisrc.lectormoe

import eu.kanade.tachiyomi.network.GET
import eu.kanade.tachiyomi.network.interceptor.rateLimitHost
import eu.kanade.tachiyomi.source.model.Filter
import eu.kanade.tachiyomi.source.model.FilterList
import eu.kanade.tachiyomi.source.model.MangasPage
import eu.kanade.tachiyomi.source.model.Page
import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import eu.kanade.tachiyomi.source.online.HttpSource
import keiyoushi.utils.parseAs
import okhttp3.Headers
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response

abstract class LectorMoe(
    override val name: String,
    override val baseUrl: String,
    override val lang: String,
    private val organizationDomain: String = baseUrl.substringAfterLast("/"),
    private val apiBaseUrl: String = "https://capibaratraductor.com",
) : HttpSource() {

    override val supportsLatest = true

    override val client: OkHttpClient = network.cloudflareClient.newBuilder()
        .rateLimitHost(baseUrl.toHttpUrl(), 3)
        .rateLimitHost(apiBaseUrl.toHttpUrl(), 3)
        .build()

    final override fun headersBuilder(): Headers.Builder = super.headersBuilder()
        .add("Referer", "$baseUrl/")

    private val apiHeaders: Headers = headersBuilder()
        .add("x-organization", organizationDomain)
        .build()

    override fun popularMangaRequest(page: Int): Request = GET("$apiBaseUrl/api/manga-custom?page=$page&limit=$PAGE_LIMIT&order=popular", apiHeaders)

    override fun popularMangaParse(response: Response): MangasPage = searchMangaParse(response)

    override fun latestUpdatesRequest(page: Int): Request = GET("$apiBaseUrl/api/manga-custom?page=$page&limit=$PAGE_LIMIT&order=latest", apiHeaders)

    override fun latestUpdatesParse(response: Response): MangasPage = searchMangaParse(response)

    override fun searchMangaRequest(page: Int, query: String, filters: FilterList): Request {
        val url = "$apiBaseUrl/api/manga-custom".toHttpUrl().newBuilder()

        url.setQueryParameter("page", page.toString())
        url.setQueryParameter("limit", PAGE_LIMIT.toString())

        filters.forEach { filter ->
            when (filter) {
                is SortByFilter -> url.setQueryParameter("order", filter.toUriPart())
                else -> {}
            }
        }

        if (query.isNotBlank()) url.setQueryParameter("title", query)

        return GET(url.build(), apiHeaders)
    }

    override fun searchMangaParse(response: Response): MangasPage {
        val page = response.request.url.queryParameter("page")!!.toInt()
        val result = response.parseAs<Data<SeriesListDataDto>>()

        val mangas = result.data.series.map { it.toSManga() }
        val hasNextPage = page < result.data.maxPage

        return MangasPage(mangas, hasNextPage)
    }

    override fun getFilterList() = FilterList(
        SortByFilter("Ordenar por", getSortList()),
    )

    private fun getSortList() = arrayOf(
        Pair("Popularidad", "popular"),
        Pair("Recientes", "latest"),
    )

    override fun getMangaUrl(manga: SManga): String = "$baseUrl/manga/${manga.url}"

    override fun mangaDetailsRequest(manga: SManga): Request = GET("$apiBaseUrl/api/manga-custom/${manga.url}", apiHeaders)

    override fun mangaDetailsParse(response: Response): SManga {
        val result = response.parseAs<Data<SeriesDto>>()
        return result.data.toSMangaDetails()
    }

    override fun getChapterUrl(chapter: SChapter): String {
        val seriesSlug = chapter.url.substringBefore("/")
        val chapterSlug = chapter.url.substringAfter("/")

        return "$baseUrl/manga/$seriesSlug/chapters/$chapterSlug"
    }

    override fun chapterListRequest(manga: SManga): Request = mangaDetailsRequest(manga)

    override fun chapterListParse(response: Response): List<SChapter> {
        val result = response.parseAs<Data<SeriesDto>>()
        val seriesSlug = result.data.manga.slug
        return result.data.chapters
            ?.filter { it.isUnreleased.not() }
            ?.map { it.toSChapter(seriesSlug) }
            ?.filter { it.date_upload < System.currentTimeMillis() }
            ?: emptyList()
    }

    override fun pageListRequest(chapter: SChapter): Request {
        val seriesSlug = chapter.url.substringBefore("/")
        val chapterSlug = chapter.url.substringAfter("/")

        return GET("$apiBaseUrl/api/manga-custom/$seriesSlug/chapter/$chapterSlug/pages", apiHeaders)
    }

    override fun pageListParse(response: Response): List<Page> {
        val result = response.parseAs<Data<List<PageDto>>>()
        return result.data.mapIndexed { i, page ->
            Page(i, imageUrl = page.imageUrl)
        }
    }

    override fun imageUrlParse(response: Response): String = throw UnsupportedOperationException()

    class SortByFilter(title: String, list: Array<Pair<String, String>>) : UriPartFilter(title, list)

    open class UriPartFilter(displayName: String, val vals: Array<Pair<String, String>>) : Filter.Select<String>(displayName, vals.map { it.first }.toTypedArray()) {
        fun toUriPart() = vals[state].second
    }

    companion object {
        private const val PAGE_LIMIT = 36
    }
}

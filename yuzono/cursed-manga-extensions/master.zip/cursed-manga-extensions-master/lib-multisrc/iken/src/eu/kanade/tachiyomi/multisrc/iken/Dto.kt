package eu.kanade.tachiyomi.multisrc.iken

import eu.kanade.tachiyomi.source.model.SChapter
import eu.kanade.tachiyomi.source.model.SManga
import keiyoushi.utils.tryParse
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonPrimitive
import org.jsoup.Jsoup
import java.text.SimpleDateFormat
import java.util.Locale

@Serializable
class SearchResponse(
    val posts: List<Manga>,
    val totalCount: Int,
)

@Serializable
class Manga(
    private val id: Int,
    val slug: String,
    private val postTitle: String,
    private val postContent: String? = null,
    val isNovel: Boolean,
    private val featuredImage: String? = null,
    private val alternativeTitles: String? = null,
    private val author: String? = null,
    private val artist: String? = null,
    private val seriesType: String? = null,
    private val seriesStatus: String? = null,
    val genres: List<Genre> = emptyList(),
) {
    fun toSManga() = SManga.create().apply {
        url = "$slug#$id"
        title = postTitle
        thumbnail_url = featuredImage
        author = this@Manga.author?.takeUnless { it.isEmpty() }
        artist = this@Manga.artist?.takeUnless { it.isEmpty() }
        description = buildString {
            postContent?.takeUnless { it.isEmpty() }?.let { desc ->
                val tmpDesc = desc.replace("\n", "<br>")

                append(Jsoup.parse(tmpDesc).text())
            }
            alternativeTitles?.takeUnless { it.isEmpty() }?.let { altName ->
                append("\n\n")
                append("Alternative Names: ")
                append(altName)
            }
        }.trim()
        genre = getGenres()
        status = when (seriesStatus) {
            "ONGOING", "COMING_SOON" -> SManga.ONGOING
            "COMPLETED" -> SManga.COMPLETED
            "CANCELLED", "DROPPED" -> SManga.CANCELLED
            else -> SManga.UNKNOWN
        }
        initialized = true
    }

    fun getGenres() = buildList {
        when (seriesType) {
            "MANGA" -> add("Manga")
            "MANHUA" -> add("Manhua")
            "MANHWA" -> add("Manhwa")
            else -> {}
        }
        genres.forEach { add(it.name) }
    }.distinct().joinToString()
}

@Serializable
class Genre(
    val id: Int,
    val name: String,
)

@Serializable
class Name(val name: String)

@Serializable
class Post<T>(val post: T)

@Serializable
class ChapterListResponse(
    val isNovel: Boolean = false,
    val slug: String? = null,
    val chapters: List<Chapter>,
)

@Serializable
class Chapter(
    private val id: Int,
    private val slug: String,
    private val number: JsonPrimitive,
    private val createdAt: String,
    private val chapterStatus: String,
    private val isAccessible: Boolean,
    private val isLocked: Boolean? = false,
    private val isTimeLocked: Boolean? = false,
    private val mangaPost: ChapterPostDetails? = null,
) {
    fun isPublic() = chapterStatus == "PUBLIC"

    fun isAccessible() = isAccessible

    fun isLocked() = (isLocked == true) || (isTimeLocked == true)

    fun toSChapter(mangaSlug: String?) = SChapter.create().apply {
        val prefix = if (!isAccessible()) "🔒 " else ""
        val seriesSlug = (mangaSlug ?: mangaPost?.slug)!!
        url = "/series/$seriesSlug/$slug#$id"
        name = "${prefix}Chapter $number"
        date_upload = dateFormat.tryParse(createdAt)
    }
}

@Serializable
class ChapterPostDetails(
    val slug: String?,
)

@Serializable
class PageParseDto(
    val url: String,
    val order: Int? = null,
)

@Serializable
class Images(
    val images: List<PageParseDto>,
)

private val dateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH)

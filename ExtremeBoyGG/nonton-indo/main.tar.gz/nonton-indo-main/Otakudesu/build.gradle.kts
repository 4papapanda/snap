version = 1

cloudstream {
    language = "id"
    authors = listOf("ExtremeBoy")
    status = 1
    tvTypes = listOf("AnimeMovie", "OVA", "Anime")
    iconUrl = "https://www.google.com/s2/favicons?domain=https://otakudesu.blog&sz=%size%"
}

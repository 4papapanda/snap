import com.android.build.gradle.BaseExtension
import com.lagradost.cloudstream3.gradle.CloudstreamExtension
import org.gradle.kotlin.dsl.register
import org.jetbrains.kotlin.gradle.dsl.JvmTarget
import org.jetbrains.kotlin.gradle.tasks.KotlinJvmCompile
import java.util.Properties

buildscript {
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
    }

    dependencies {
        classpath("com.android.tools.build:gradle:8.13.2")
        classpath("com.github.recloudstream.gradle:gradle:81b1d424d")
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.3.0")
    }
}

allprojects {
    repositories {
        google()
        mavenCentral()
        maven("https://jitpack.io")
    }
}

// Load secrets from local.properties if available
val localProperties = Properties().apply {
    val localFile = rootProject.file("local.properties")
    if (localFile.exists()) {
        localFile.inputStream().use { load(it) }
    }
}

// Helper to read secret from local.properties or system environment or fallback
fun getSecret(key: String, fallback: String = ""): String {
    return localProperties.getProperty(key)
        ?: System.getenv(key)
        ?: fallback
}


fun Project.cloudstream(configuration: CloudstreamExtension.() -> Unit) = extensions.getByName<CloudstreamExtension>("cloudstream").configuration()

fun Project.android(configuration: BaseExtension.() -> Unit) = extensions.getByName<BaseExtension>("android").configuration()

subprojects {
    apply(plugin = "com.android.library")
    apply(plugin = "kotlin-android")
    apply(plugin = "com.lagradost.cloudstream3.gradle")

    cloudstream {
        setRepo("https://github.com/xr3ed/M3U-Playlist-Player-Repo-for-Cloudstream")
        authors = listOf("xr3ed")
    }

    android {
        namespace = "com.xr3ed"

        defaultConfig {
            minSdk = 21
            compileSdkVersion(35)
            targetSdk = 35

            // Inject secrets into BuildConfig
            buildConfigField("String", "CLONER_SIGNATURE", "\"${getSecret("CLONER_SIGNATURE", "dummy")}\"")
            buildConfigField("String", "UPDATE_JSON_URL", "\"${getSecret("UPDATE_JSON_URL", "https://raw.githubusercontent.com/xr3ed/CloudStreamXR/main/update.json")}\"")
            buildConfigField("String", "FALLBACK_RELEASE_URL", "\"${getSecret("FALLBACK_RELEASE_URL", "https://github.com/xr3ed/CloudStreamXR")}\"")
            buildConfigField("String", "MOVIEBOX_SECRET_KEY_DEFAULT", "\"${getSecret("MOVIEBOX_SECRET_KEY_DEFAULT")}\"")
            buildConfigField("String", "MOVIEBOX_SECRET_KEY_ALT", "\"${getSecret("MOVIEBOX_SECRET_KEY_ALT")}\"")
            buildConfigField("String", "CASTLE_SUFFIX", "\"${getSecret("CASTLE_SUFFIX")}\"")
            buildConfigField("String", "SIMKL_API", "\"${getSecret("SIMKL_API")}\"")
            buildConfigField("String", "MAL_API", "\"${getSecret("MAL_API")}\"")
            buildConfigField("String", "LIBRARY_PACKAGE_NAME", "\"com.xr3ed\"")
            val rawMeloloUrl = getSecret("MELOLO_URL", "dummy")
            val base64MeloloUrl = if (rawMeloloUrl == "dummy") "dummy" else java.util.Base64.getEncoder().encodeToString(rawMeloloUrl.toByteArray())
            val rawMeloloApiPath = getSecret("MELOLO_API_PATH", "dummy")
            val base64MeloloApiPath = if (rawMeloloApiPath == "dummy") "dummy" else java.util.Base64.getEncoder().encodeToString(rawMeloloApiPath.toByteArray())

            buildConfigField("String", "SHORTMAX_URL", "\"${getSecret("SHORTMAX_URL", "dummy")}\"")
            buildConfigField("String", "SHORTMAX_KEY", "\"${getSecret("SHORTMAX_KEY", "dummy")}\"")
            buildConfigField("String", "MELOLO_URL", "\"$base64MeloloUrl\"")
            buildConfigField("String", "MELOLO_API_PATH", "\"$base64MeloloApiPath\"")
            buildConfigField("String", "CRICIFY_PROVIDER_SECRET1", "\"${getSecret("CRICIFY_PROVIDER_SECRET1")}\"")
            buildConfigField("String", "CRICIFY_PROVIDER_SECRET2", "\"${getSecret("CRICIFY_PROVIDER_SECRET2")}\"")
            buildConfigField("String", "PIKASHOW_API_KEY", "\"${getSecret("PIKASHOW_API_KEY")}\"")
            buildConfigField("String", "PIKASHOW_HMAC_SECRET", "\"${getSecret("PIKASHOW_HMAC_SECRET")}\"")
            buildConfigField("String", "CRICFY_FIREBASE_API_KEY", "\"${getSecret("CRICFY_FIREBASE_API_KEY")}\"")
            buildConfigField("String", "CRICFY_FIREBASE_APP_ID", "\"${getSecret("CRICFY_FIREBASE_APP_ID")}\"")
            buildConfigField("String", "CRICFY_FIREBASE_PROJECT_NUMBER", "\"${getSecret("CRICFY_FIREBASE_PROJECT_NUMBER")}\"")
            buildConfigField("String", "SKLIVE_KEY", "\"${getSecret("SKLIVE_KEY")}\"")
            buildConfigField("String", "SKLIVE_IV", "\"${getSecret("SKLIVE_IV")}\"")
            buildConfigField("String", "SKLIVE_V23_KEY", "\"${getSecret("SKLIVE_V23_KEY")}\"")
            buildConfigField("String", "SKLIVE_V23_IV", "\"${getSecret("SKLIVE_V23_IV")}\"")
            buildConfigField("String", "SKTECH_FIREBASE_API_KEY", "\"${getSecret("SKTECH_FIREBASE_API_KEY")}\"")
            buildConfigField("String", "SKTECH_FIREBASE_APP_ID", "\"${getSecret("SKTECH_FIREBASE_APP_ID")}\"")
            buildConfigField("String", "SKTECH_FIREBASE_PROJECT_NUMBER", "\"${getSecret("SKTECH_FIREBASE_PROJECT_NUMBER")}\"")
            buildConfigField("String", "XON_FIREBASE_API_KEY", "\"${getSecret("XON_FIREBASE_API_KEY")}\"")
            buildConfigField("String", "XON_FIREBASE_APP_ID", "\"${getSecret("XON_FIREBASE_APP_ID")}\"")
            buildConfigField("String", "XON_FIREBASE_PROJECT_NUMBER", "\"${getSecret("XON_FIREBASE_PROJECT_NUMBER")}\"")
            buildConfigField("String", "CINETV_SECRET_KEY_ENCRYPTED", "\"${getSecret("CINETV_SECRET_KEY_ENCRYPTED")}\"")
            buildConfigField("String", "CINETV_DES_KEY", "\"${getSecret("CINETV_DES_KEY")}\"")
            buildConfigField("String", "CINETV_DES_IV", "\"${getSecret("CINETV_DES_IV")}\"")
            buildConfigField("String", "CINETV_AES_KEY", "\"${getSecret("CINETV_AES_KEY")}\"")
            buildConfigField("String", "CINETV_AES_IV", "\"${getSecret("CINETV_AES_IV")}\"")
            buildConfigField("String", "CINETV_WS_SECRET", "\"${getSecret("CINETV_WS_SECRET")}\"")
            buildConfigField("String", "SMARTLINK_URL", "\"${getSecret("SMARTLINK_URL")}\"")
            buildConfigField("String", "SPEEDLINK_URL", "\"${getSecret("SPEEDLINK_URL")}\"")
            // RBTV+ secrets — disembunyikan agar tidak bisa dicari di GitHub
            buildConfigField("String", "RBTV_MAIN_URL", "\"${getSecret("RBTV_MAIN_URL")}\"")
            buildConfigField("String", "RBTV_API_HOST", "\"${getSecret("RBTV_API_HOST")}\"")
            buildConfigField("String", "RBTV_AES_KEY", "\"${getSecret("RBTV_AES_KEY", "a7981cc9eb2f4d19dcfea57b101ecd89")}\"")
            buildConfigField("String", "RBTV_AES_IV", "\"${getSecret("RBTV_AES_IV", "8017d3a8f1400d2f")}\"")
            // Xr3edEvent secrets — disembunyikan agar tidak bisa dicari di GitHub
            buildConfigField("String", "XR3EV_MAIN_URL", "\"${getSecret("XR3EV_MAIN_URL")}\"")
            buildConfigField("String", "XR3EV_API_URL", "\"${getSecret("XR3EV_API_URL")}\"")
            buildConfigField("String", "XR3EV_PLAYER_URL", "\"${getSecret("XR3EV_PLAYER_URL")}\"")
            buildConfigField("String", "XR3EV_STREAM_URL", "\"${getSecret("XR3EV_STREAM_URL")}\"")
            buildConfigField("String", "XR3EV_PASSWORD", "\"${getSecret("XR3EV_PASSWORD", "xys1-gh")}\"")
            buildConfigField("String", "XR3EV_SALT", "\"${getSecret("XR3EV_SALT", "salt123")}\"")
            // xr3edXstream secrets — TMDB API key untuk akses listing film/TV
            buildConfigField("String", "XSTREAM_TMDB_API", "\"${getSecret("XSTREAM_TMDB_API")}\"")
        }

        testOptions {
            unitTests.isReturnDefaultValues = true
        }

        compileOptions {
            sourceCompatibility = JavaVersion.VERSION_1_8
            targetCompatibility = JavaVersion.VERSION_1_8
        }


        tasks.withType<KotlinJvmCompile> {
            compilerOptions {
                jvmTarget.set(JvmTarget.JVM_1_8)
                freeCompilerArgs.addAll(
                    "-Xno-call-assertions",
                    "-Xno-param-assertions",
                    "-Xno-receiver-assertions",
                    "-Xannotation-default-target=param-property"
                )
            }
        }
    }

    dependencies {
        val testImplementation by configurations
        testImplementation("junit:junit:4.13.2")
        testImplementation("org.robolectric:robolectric:4.11.1")
        testImplementation(files("${System.getProperty("user.home")}/.gradle/caches/cloudstream/cloudstream/cloudstream.jar"))
        val implementation by configurations
        val cloudstream by configurations
        cloudstream("com.lagradost:cloudstream3:pre-release")

        // Other dependencies
        implementation(kotlin("stdlib"))
        implementation("androidx.appcompat:appcompat:1.6.1")
        implementation("com.google.android.material:material:1.11.0")
        implementation("com.github.Blatzar:NiceHttp:0.4.16")
        implementation("org.jsoup:jsoup:1.22.1")
        implementation("androidx.annotation:annotation:1.9.1")
        implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.20.1")
        implementation("com.fasterxml.jackson.core:jackson-databind:2.20.1")
        implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
        implementation("org.mozilla:rhino:1.9.0")
        implementation("me.xdrop:fuzzywuzzy:1.4.0")
        implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")
        implementation("com.github.vidstige:jadb:v1.2.1")
        implementation("org.bouncycastle:bcpkix-jdk15on:1.70")
    }
}

tasks.register<Delete>("clean") {
    delete(rootProject.layout.buildDirectory)
}
﻿package com.sad25kag

import com.lagradost.cloudstream3.plugins.BasePlugin
import com.lagradost.cloudstream3.plugins.CloudstreamPlugin

@CloudstreamPlugin
class AnimesaltProvider : BasePlugin() {
    override fun load() {
        registerMainAPI(Animesalt())
        registerExtractorAPI(Pixdrive())
        registerExtractorAPI(Ghbrisk())
        registerExtractorAPI(AWSStream())
        registerExtractorAPI(Zephyrflick())
        registerExtractorAPI(betaAwstream())
        registerExtractorAPI(MegaPlay())
        registerExtractorAPI(Rapid())
        registerExtractorAPI(ascdn21())
        registerExtractorAPI(Abyass())
        registerExtractorAPI(AnimesaltMulti())
        registerExtractorAPI(Short())
    }
}

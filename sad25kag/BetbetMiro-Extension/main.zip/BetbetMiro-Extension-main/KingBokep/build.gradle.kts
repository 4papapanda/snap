version = 4

cloudstream {
    language = "id"
    description = "KingBokep provider dengan struktur split dan kategori terbaru dari website sumber."
    authors = listOf("status")
    status = 1
    tvTypes = listOf("NSFW")
    iconUrl = "https://www.google.com/s2/favicons?domain=kingbokep.tv&sz=256"
}

version = 15


cloudstream {
    language = "id"
    // All of these properties are optional, you can safely remove them

    description = "type .nofap in discord - Full Length"
    authors = listOf("sad25kag")

    /**
     * Status int as the following:
     * 0: Down
     * 1: Ok
     * 2: Slow
     * 3: Beta only
     * */
    status = 1 // will be 3 if unspecified
    tvTypes = listOf(
        "NSFW",
    )

    iconUrl = "https://www.google.com/s2/favicons?domain=noodlemagazine.com/&sz=%size%"
}

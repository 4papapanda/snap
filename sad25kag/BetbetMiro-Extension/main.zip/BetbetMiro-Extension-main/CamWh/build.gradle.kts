version = 13

cloudstream {
    authors = listOf("sad25kag")
    language = "id"
    description = "Provider NSFW untuk konten video dewasa dari CamWH."

    /**
     * Status int:
     * 0: Down
     * 1: Ok
     * 2: Slow
     * 3: Beta only
     */
    status = 1
    tvTypes = listOf("NSFW")
    iconUrl = "https://camwh.com/contents/ugmtofwqltgh/theme/logo.png"
}
